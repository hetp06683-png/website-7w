export interface MenuItem {
  id: string;
  name: string;
  price: number;
  image: string;
  desc: string;
  category: 'starters' | 'mains' | 'seafood' | 'drinks' | 'desserts';
  ingredients: string[];
  spicinessLevel?: boolean; // If true, show spice level selector
  isVeg?: boolean;
  isBestseller?: boolean;
  rating?: number;
  prepTime?: string;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  spiceLevel?: 'Mild' | 'Medium' | 'Hot' | 'Very Hot';
  customNotes?: string;
}

export interface Order {
  id: string;
  tableId: string;
  items: CartItem[];
  subtotal: number;
  gst: number;
  serviceCharge: number;
  total: number;
  status: 'received' | 'preparing' | 'almost_ready' | 'served';
  timestamp: string;
}

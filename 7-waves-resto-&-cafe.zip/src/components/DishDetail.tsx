import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, Flame, Check, MessageSquare, Clock, Star } from 'lucide-react';
import { motion } from 'motion/react';
import { MenuItem } from '../types';

interface DishDetailProps {
  item: MenuItem | null;
  onClose: () => void;
  onAddToCart: (item: MenuItem, quantity: number, spiceLevel?: any, customNotes?: string) => void;
  currentCartQuantity: number;
  isDarkMode?: boolean;
}

const SPICE_LEVELS = [
  { id: 'Mild', label: 'Mild 🌱' },
  { id: 'Medium', label: 'Medium 🔥' },
  { id: 'Hot', label: 'Spicy 🔥🔥' },
  { id: 'Very Hot', label: 'Extra Hot 🌶️' }
];

export default function DishDetail({
  item,
  onClose,
  onAddToCart,
  currentCartQuantity,
  isDarkMode = false
}: DishDetailProps) {
  const [quantity, setQuantity] = useState(1);
  const [selectedSpice, setSelectedSpice] = useState<'Mild' | 'Medium' | 'Hot' | 'Very Hot'>('Medium');
  const [notes, setNotes] = useState('');

  // Reset local state when item changes
  useEffect(() => {
    if (item) {
      setQuantity(currentCartQuantity > 0 ? currentCartQuantity : 1);
      setSelectedSpice('Medium');
      setNotes('');
    }
  }, [item, currentCartQuantity]);

  if (!item) return null;

  const handleAddClick = () => {
    onAddToCart(item, quantity, item.spicinessLevel ? selectedSpice : undefined, notes.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/75 backdrop-blur-xs">
      {/* Tap backdrop to close */}
      <div className="absolute inset-0 cursor-pointer" onClick={onClose} />

      {/* Slide-Up Bottom Sheet */}
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 220 }}
        className={`relative w-full max-w-md rounded-t-[2.5rem] overflow-hidden shadow-2xl z-10 max-h-[92vh] flex flex-col ${
          isDarkMode ? 'bg-[#0E1A2B] text-white' : 'bg-white text-gray-900'
        }`}
      >
        {/* Apple-style Drag Handle Indicator */}
        <div className="w-full flex justify-center pt-3 pb-1">
          <div className={`w-12 h-1.5 rounded-full ${isDarkMode ? 'bg-blue-900/40' : 'bg-gray-200'}`} onClick={onClose} />
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 bg-black/40 hover:bg-black/60 text-white rounded-full p-2 transition-colors duration-200 cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Scrollable Content Container */}
        <div className="overflow-y-auto flex-1 pb-24">
          {/* Hero Banner */}
          <div className="relative h-64 w-full bg-gray-100/5">
            <img
              src={item.image}
              alt={item.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            <div className="absolute bottom-6 left-6 flex items-center gap-2">
              <span className="bg-amber-500/90 backdrop-blur-xs text-white text-[10px] font-sans font-semibold tracking-widest uppercase px-3 py-1 rounded-full">
                {item.category}
              </span>
              {item.isVeg ? (
                <span className="bg-emerald-600/95 text-white text-[10px] font-sans font-semibold px-2.5 py-1 rounded-full">
                  Veg
                </span>
              ) : (
                <span className="bg-rose-600/95 text-white text-[10px] font-sans font-semibold px-2.5 py-1 rounded-full">
                  Non-Veg
                </span>
              )}
            </div>
          </div>

          {/* Details Section */}
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <h2 className={`font-serif font-black text-2.5xl leading-tight pr-4 ${isDarkMode ? 'text-white' : 'text-gray-950'}`}>
                {item.name}
              </h2>
              <span className="font-serif font-black text-xl text-amber-500 shrink-0">
                ₹{item.price}
              </span>
            </div>

            {/* Prep and rating line */}
            <div className="flex items-center space-x-4 mb-4 text-xs">
              {item.rating && (
                <div className="flex items-center space-x-1">
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                  <span className={`font-bold ${isDarkMode ? 'text-white' : 'text-gray-950'}`}>{item.rating} Rating</span>
                </div>
              )}
              <div className="flex items-center space-x-1 text-gray-400">
                <Clock className="h-3.5 w-3.5" />
                <span>{item.prepTime || '15 mins'} prep time</span>
              </div>
            </div>

            <p className={`text-sm leading-relaxed mb-6 font-sans ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {item.desc}
            </p>

            {/* Ingredients Chip List */}
            <div className="mb-6">
              <h4 className={`text-xs font-sans tracking-wider uppercase font-bold mb-3 ${isDarkMode ? 'text-amber-400/80' : 'text-gray-400'}`}>
                Signature Ingredients
              </h4>
              <div className="flex flex-wrap gap-2">
                {item.ingredients.map((ing, idx) => (
                  <span
                    key={idx}
                    className={`text-xs px-3 py-1.5 rounded-full font-medium ${
                      isDarkMode 
                        ? 'bg-blue-950/40 border border-blue-900/30 text-gray-300' 
                        : 'bg-gray-50 border border-gray-100/70 text-gray-600'
                    }`}
                  >
                    {ing}
                  </span>
                ))}
              </div>
            </div>

            {/* Spice Level Section */}
            {item.spicinessLevel && (
              <div className={`mb-6 p-4 rounded-2xl border ${
                isDarkMode ? 'bg-blue-950/20 border-blue-900/30' : 'bg-gray-50/60 border-gray-100'
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-1.5">
                    <Flame className="h-4 w-4 text-red-500 animate-pulse" />
                    <h4 className={`text-xs font-sans tracking-wider uppercase font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Customize Heat Level
                    </h4>
                  </div>
                  <span className="text-xs font-extrabold text-amber-500 font-sans">
                    {selectedSpice}
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-2">
                  {SPICE_LEVELS.map((spice) => {
                    const isSelected = selectedSpice === spice.id;
                    return (
                      <button
                        key={spice.id}
                        type="button"
                        onClick={() => setSelectedSpice(spice.id as any)}
                        className={`py-2 px-1 rounded-xl text-[11px] font-sans font-bold text-center border transition-all duration-200 cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500 border-amber-600 text-white shadow-sm'
                            : isDarkMode 
                              ? 'bg-blue-950 border-blue-900/20 text-gray-300 hover:bg-blue-900/20' 
                              : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        {spice.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Custom Notes Section */}
            <div className={`mb-4 p-4 rounded-2xl border ${
              isDarkMode ? 'bg-blue-950/20 border-blue-900/30' : 'bg-gray-50/60 border-gray-100'
            }`}>
              <div className="flex items-center space-x-1.5 mb-2.5">
                <MessageSquare className="h-4 w-4 text-amber-500" />
                <h4 className={`text-xs font-sans tracking-wider uppercase font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  Kitchen Instructions (Optional)
                </h4>
              </div>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. No onion, extra spicy, sauce on the side..."
                className={`w-full text-xs p-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 resize-none h-18 ${
                  isDarkMode 
                    ? 'bg-[#0B0B0F] border-blue-900/30 text-white placeholder-gray-500' 
                    : 'bg-white border-gray-200 text-gray-800 placeholder-gray-400'
                }`}
              />
            </div>

          </div>
        </div>

        {/* Bottom Sticky Action Bar */}
        <div className={`absolute bottom-0 left-0 right-0 border-t px-6 py-4 flex items-center justify-between shadow-[0_-8px_30px_rgb(0,0,0,0.06)] ${
          isDarkMode ? 'bg-[#0E1A2B]/95 border-blue-950' : 'bg-white/95 border-gray-100'
        }`}>
          {/* Quantity Controls */}
          <div className={`flex items-center border rounded-full px-2 py-1.5 space-x-4 ${
            isDarkMode ? 'bg-blue-950/50 border-blue-900/40' : 'bg-gray-100 border-gray-200/40'
          }`}>
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className={`w-8 h-8 rounded-full flex items-center justify-center active:scale-95 transition-all cursor-pointer shadow-xs border ${
                isDarkMode 
                  ? 'bg-[#0B0B0F] border-blue-900/30 text-gray-300 hover:bg-blue-950' 
                  : 'bg-white border-gray-200/30 text-gray-800 hover:bg-gray-50'
              }`}
            >
              <Minus className="h-3.5 w-3.5" />
            </button>
            <span className={`font-sans font-black text-base w-4 text-center ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {quantity}
            </span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className={`w-8 h-8 rounded-full flex items-center justify-center active:scale-95 transition-all cursor-pointer shadow-xs border ${
                isDarkMode 
                  ? 'bg-[#0B0B0F] border-blue-900/30 text-gray-300 hover:bg-blue-950' 
                  : 'bg-white border-gray-200/30 text-gray-800 hover:bg-gray-50'
              }`}
            >
              <Plus className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Add / Update CTA Button */}
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleAddClick}
            className="flex-1 ml-4 bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-white font-sans font-bold text-sm py-3 px-5 rounded-full shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center space-x-2 cursor-pointer"
          >
            <Check className="h-4.5 w-4.5" />
            <span>
              {currentCartQuantity > 0 ? 'Update Cart' : 'Add to Table Cart'} • ₹{item.price * quantity}
            </span>
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}

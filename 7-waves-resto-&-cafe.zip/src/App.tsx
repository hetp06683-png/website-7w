import React, { useState, useEffect } from 'react';
import { Waves, QrCode, Sparkles, ChefHat, Compass, LogOut, Search, Filter, X, Globe, RefreshCw, ExternalLink, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Type declarations
import { MenuItem, CartItem, Order } from './types';

// Menu database
import { MENU_ITEMS } from './data/menu';

// Components
import Header from './components/Header';
import CategoryTabs from './components/CategoryTabs';
import FoodCard from './components/FoodCard';
import DishDetail from './components/DishDetail';
import CartView from './components/CartView';
import OrderTracking from './components/OrderTracking';
import QRGenerator from './components/QRGenerator';
import QREntryScreen from './components/QREntryScreen';
import BrandLogo from './components/BrandLogo';
import QRScannerModal from './components/QRScannerModal';

export default function App() {
  // Navigation & session state
  const [tableId, setTableId] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'welcome' | 'table_confirmed' | 'menu' | 'cart' | 'order_tracking' | 'admin'>('welcome');
  const [welcomeTab, setWelcomeTab] = useState<'hero' | 'qrs' | 'about'>('hero');
  
  // Scanner and modal overlays
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showReserveModal, setShowReserveModal] = useState(false);
  
  // Theme state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('7waves_dark_mode') === 'true';
    }
    return false;
  });

  const handleToggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  // Menu items categories
  const [selectedCategory, setSelectedCategory] = useState<'starters' | 'mains' | 'seafood' | 'drinks' | 'desserts'>('starters');
  
  // Menu Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [filterVegOnly, setFilterVegOnly] = useState(false);
  const [filterBestsellerOnly, setFilterBestsellerOnly] = useState(false);

  // Selection details state
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);

  // Cart & Order states
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  // QR Target URL settings to allow physical scanning across custom environments (such as GitHub Pages or local preview)
  const [customBaseUrl, setCustomBaseUrl] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('7waves_custom_qr_base_url') || '';
    }
    return '';
  });

  const getDerivedTargetUrl = (tableNum: number) => {
    let base = customBaseUrl.trim();
    if (!base) {
      base = typeof window !== 'undefined' ? window.location.origin : 'https://the7waves.com';
    }
    // Clean up trailing slash
    if (base.endsWith('/')) {
      base = base.slice(0, -1);
    }
    return `${base}?table=${tableNum}`;
  };

  // Parse Table ID from URL or localStorage on startup
  useEffect(() => {
    // 1. Check URL parameters e.g. ?table=12
    const searchParams = new URLSearchParams(window.location.search);
    let detectedTable = searchParams.get('table') || searchParams.get('tableId');

    // 2. Check path e.g. /table/12
    if (!detectedTable) {
      const match = window.location.pathname.match(/\/table\/(\d+)/);
      if (match) {
        detectedTable = match[1];
      }
    }

    // 3. Fallback to localStorage
    if (!detectedTable) {
      detectedTable = localStorage.getItem('7waves_table_id');
    }

    if (detectedTable) {
      setTableId(detectedTable);
      localStorage.setItem('7waves_table_id', detectedTable);
      
      // If we just detected a table, prompt table confirmation screen
      setCurrentView('table_confirmed');
    } else {
      setCurrentView('welcome');
    }

    // Load active cart from localStorage if present
    const savedCart = localStorage.getItem('7waves_cart');
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (e) {
        console.error('Failed to parse cart', e);
      }
    }

    // Load active order if present
    const savedOrder = localStorage.getItem('7waves_active_order');
    if (savedOrder) {
      try {
        setActiveOrder(JSON.parse(savedOrder));
      } catch (e) {
        console.error('Failed to parse active order', e);
      }
    }
  }, []);

  // Sync theme to localStorage
  useEffect(() => {
    localStorage.setItem('7waves_dark_mode', isDarkMode.toString());
  }, [isDarkMode]);

  // Sync cart to localStorage
  useEffect(() => {
    localStorage.setItem('7waves_cart', JSON.stringify(cart));
  }, [cart]);

  // Sync active order to localStorage
  useEffect(() => {
    if (activeOrder) {
      localStorage.setItem('7waves_active_order', JSON.stringify(activeOrder));
    } else {
      localStorage.removeItem('7waves_active_order');
    }
  }, [activeOrder]);

  // --- CART OPERATIONS ---
  const handleAddToCart = (item: MenuItem, quantity: number, spiceLevel?: 'Mild' | 'Medium' | 'Hot' | 'Very Hot', customNotes?: string) => {
    setCart((prevCart) => {
      // Clean up if quantity is 0
      if (quantity === 0) {
        return prevCart.filter((c) => c.menuItem.id !== item.id);
      }

      const existingIdx = prevCart.findIndex(
        (c) => c.menuItem.id === item.id
      );

      if (existingIdx > -1) {
        const updated = [...prevCart];
        updated[existingIdx].quantity = quantity;
        if (spiceLevel) updated[existingIdx].spiceLevel = spiceLevel;
        if (customNotes !== undefined) updated[existingIdx].customNotes = customNotes;
        return updated;
      } else {
        return [...prevCart, { menuItem: item, quantity, spiceLevel, customNotes }];
      }
    });
  };

  const handleIncrementCart = (index: number) => {
    setCart((prev) => {
      const updated = [...prev];
      updated[index].quantity += 1;
      return updated;
    });
  };

  const handleDecrementCart = (index: number) => {
    setCart((prev) => {
      const updated = [...prev];
      if (updated[index].quantity > 1) {
        updated[index].quantity -= 1;
      } else {
        updated.splice(index, 1);
      }
      return updated;
    });
  };

  const handleRemoveCartItem = (index: number) => {
    setCart((prev) => {
      const updated = [...prev];
      updated.splice(index, 1);
      return updated;
    });
  };

  const handleUpdateCartItemNotes = (index: number, notes: string) => {
    setCart((prev) => {
      const updated = [...prev];
      updated[index].customNotes = notes;
      return updated;
    });
  };

  // --- PLACE SECURE ORDER ---
  const handlePlaceOrder = () => {
    if (cart.length === 0) return;

    const subtotal = cart.reduce((acc, item) => acc + item.menuItem.price * item.quantity, 0);
    const gst = Math.round(subtotal * 0.05);
    const serviceCharge = Math.round(subtotal * 0.05);
    const total = subtotal + gst + serviceCharge;

    const newOrder: Order = {
      id: Math.floor(1000 + Math.random() * 9000).toString(),
      tableId: tableId || '12',
      items: [...cart],
      subtotal,
      gst,
      serviceCharge,
      total,
      status: 'received',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setActiveOrder(newOrder);
    setCart([]); // Clear cart after ordering
    setCurrentView('order_tracking');
  };

  // --- SIMULATION HELPERS ---
  const handleSimulateTableScan = (selectedId: string) => {
    setTableId(selectedId);
    localStorage.setItem('7waves_table_id', selectedId);
    
    // Clear other orders and cart so we have a clean simulation
    setCart([]);
    setActiveOrder(null);
    localStorage.removeItem('7waves_active_order');

    setCurrentView('table_confirmed');
  };

  const handleAdvanceStatus = () => {
    if (!activeOrder) return;
    
    let nextStatus: 'received' | 'preparing' | 'almost_ready' | 'served' = 'received';
    if (activeOrder.status === 'received') nextStatus = 'preparing';
    else if (activeOrder.status === 'preparing') nextStatus = 'almost_ready';
    else if (activeOrder.status === 'almost_ready') nextStatus = 'served';
    else return;

    setActiveOrder({
      ...activeOrder,
      status: nextStatus
    });
  };

  const handleLogoutTable = () => {
    setTableId(null);
    setCart([]);
    setActiveOrder(null);
    localStorage.removeItem('7waves_table_id');
    localStorage.removeItem('7waves_cart');
    localStorage.removeItem('7waves_active_order');
    setCurrentView('welcome');
  };

  // Get count of total items in cart
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Filter menu items by category + filters + search
  const filteredMenuItems = MENU_ITEMS.filter((item) => {
    const matchesCategory = item.category === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.ingredients.some(i => i.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesVeg = !filterVegOnly || item.isVeg === true;
    const matchesBestseller = !filterBestsellerOnly || item.isBestseller === true;

    return matchesCategory && matchesSearch && matchesVeg && matchesBestseller;
  });

  return (
    <div className={`min-h-screen font-sans antialiased selection:bg-amber-100 selection:text-amber-900 transition-colors duration-300 ${
      isDarkMode ? 'bg-[#050508]' : 'bg-[#F7F9FC]'
    }`}>
      <div className={`max-w-md mx-auto min-h-screen shadow-2xl relative flex flex-col justify-between transition-colors duration-300 ${
        isDarkMode ? 'bg-[#0B0B0F]' : 'bg-white'
      }`}>
        
        {/* --- VIEW SWITCHER ENGINE --- */}
        <AnimatePresence mode="wait">
          
          {/* 1. NO TABLE SELECTED (PREMIUM BRAND LANDING PAGE) */}
          {currentView === 'welcome' && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className={`relative min-h-screen flex flex-col justify-between overflow-x-hidden transition-colors duration-300 ${
                isDarkMode 
                  ? 'bg-[#0B0B0F] text-white' 
                  : 'bg-[#F7F9FC] text-gray-950'
              }`}
              style={welcomeTab === 'hero' ? {
                backgroundImage: `url('https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=1600&auto=format&fit=crop')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              } : undefined}
            >
              {/* Dark Overlay Vignette (Only on Hero Tab to keep QR tab highly readable) */}
              {welcomeTab === 'hero' && (
                <div className="absolute inset-0 bg-gradient-to-b from-black/85 via-black/70 to-black/95 backdrop-blur-[1px]" />
              )}

              {/* Brand Navigation Header */}
              <header className={`relative z-10 px-4 py-3.5 flex items-center justify-between border-b backdrop-blur-md transition-colors duration-200 ${
                welcomeTab === 'hero' 
                  ? 'border-white/10 bg-black/40 text-white' 
                  : isDarkMode 
                    ? 'border-blue-950 bg-[#0E1A2B]/80 text-white' 
                    : 'border-gray-200 bg-white/80 text-gray-900'
              }`}>
                <BrandLogo className="h-10" showText={true} isDarkMode={welcomeTab === 'hero' || isDarkMode} />
                
                {/* Nav Links */}
                <nav className="flex items-center space-x-3 text-[10px] font-sans font-bold uppercase tracking-wider">
                  <button 
                    onClick={() => setWelcomeTab('hero')} 
                    className={`transition-colors cursor-pointer ${
                      welcomeTab === 'hero' 
                        ? 'text-[#F5C542]' 
                        : isDarkMode 
                          ? 'text-gray-300 hover:text-[#F5C542]' 
                          : 'text-gray-600 hover:text-[#F5C542]'
                    }`}
                  >
                    Home
                  </button>
                  <button 
                    onClick={() => setWelcomeTab('qrs')} 
                    className={`transition-colors cursor-pointer ${
                      welcomeTab === 'qrs' 
                        ? 'text-[#F5C542]' 
                        : isDarkMode 
                          ? 'text-gray-300 hover:text-[#F5C542]' 
                          : 'text-gray-600 hover:text-[#F5C542]'
                    }`}
                  >
                    Table QRs (1-25)
                  </button>
                  <button 
                    onClick={() => setWelcomeTab('about')} 
                    className={`transition-colors cursor-pointer ${
                      welcomeTab === 'about' 
                        ? 'text-[#F5C542]' 
                        : isDarkMode 
                          ? 'text-gray-300 hover:text-[#F5C542]' 
                          : 'text-gray-600 hover:text-[#F5C542]'
                    }`}
                  >
                    Story
                  </button>
                </nav>
              </header>

              {/* TAB CONTAINER CONTENT */}
              <div className="relative z-10 flex-1 flex flex-col">
                
                {/* A. HERO COVER HOME TAB */}
                {welcomeTab === 'hero' && (
                  <div className="my-auto px-5 max-w-md mx-auto flex flex-col items-center py-8 text-center">
                    <motion.div
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="inline-flex items-center space-x-1.5 bg-[#F5C542]/15 text-[#F5C542] px-3.5 py-1.5 rounded-full text-[9px] font-sans font-bold uppercase tracking-wider border border-[#F5C542]/25 mb-5"
                    >
                      <Sparkles className="h-3 w-3 animate-pulse" />
                      <span>Mumbai's Finest Beachfront Dining</span>
                    </motion.div>

                    <motion.h3 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.15 }}
                      className="font-serif italic text-lg sm:text-xl text-[#F5C542]"
                    >
                      Savor the Flavours of
                    </motion.h3>

                    <motion.h1
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.25 }}
                      className="font-serif font-black text-3xl sm:text-4xl tracking-tight leading-none text-white mt-1 mb-4"
                    >
                      The 7 Waves
                    </motion.h1>

                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.35 }}
                      className="text-[11px] text-gray-300 leading-relaxed font-sans max-w-sm tracking-wide text-center mb-8"
                    >
                      Exquisite multicuisine delicacies delivered directly to your beachfront table. Touchless ordering, real-time tracking, unparalleled taste.
                    </motion.p>

                    {/* Live Open Table Banner */}
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                      onClick={() => handleSimulateTableScan("1")}
                      className="w-full bg-emerald-500/10 border border-emerald-500/25 rounded-2xl p-4 mb-6 text-left cursor-pointer hover:bg-emerald-500/15 transition-all duration-300 group max-w-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="relative flex h-2 w-2 shrink-0">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                          </span>
                          <span className="text-[10px] uppercase font-sans font-black tracking-widest text-emerald-400">
                            Table 01 Open Session
                          </span>
                        </div>
                        <span className="text-[8px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded-md font-sans uppercase font-bold group-hover:scale-105 transition-transform">
                          Live Active
                        </span>
                      </div>
                      <h4 className="font-serif font-black text-xs text-white mt-1.5">
                        Table 01 is open for scanning!
                      </h4>
                      <p className="text-[10px] text-gray-300 mt-1 leading-relaxed font-sans">
                        Scan the brand QR or tap here to join Table 01 immediately and begin touchless ordering.
                      </p>
                    </motion.div>

                    {/* Action buttons inside landing hero page */}
                    <div className="space-y-3 w-full max-w-xs">
                      {/* Scan Table QR Button */}
                      <button
                        onClick={() => setIsScannerOpen(true)}
                        className="w-full bg-[#F5C542] hover:bg-[#e0b232] text-black font-sans font-extrabold text-[11px] py-3.5 rounded-xl tracking-wider uppercase transition-all duration-300 shadow-lg cursor-pointer flex items-center justify-center space-x-2"
                      >
                        <QrCode className="h-4 w-4 text-black" />
                        <span>Scan Table QR Code</span>
                      </button>

                      {/* Explore Tables (Tables 1-25) */}
                      <button
                        onClick={() => setWelcomeTab('qrs')}
                        className="w-full bg-white/10 hover:bg-white/15 text-white border border-white/20 font-sans font-bold text-[11px] py-3.5 rounded-xl tracking-wider uppercase transition-all duration-300 cursor-pointer flex items-center justify-center space-x-2"
                      >
                        <Compass className="h-4 w-4 text-[#F5C542]" />
                        <span>View Table QRs (1-25)</span>
                      </button>
                    </div>

                    <div className="mt-8 border-t border-white/10 pt-4 w-full text-center">
                      <p className="text-[9px] text-gray-400">
                        * Grab any Table QR placard below to start ordering simulator sessions.
                      </p>
                    </div>
                  </div>
                )}

                {/* B. EVERY TABLE QR CODE PLACARDS (1 TO 25) */}
                {welcomeTab === 'qrs' && (
                  <div className={`flex-1 p-4 ${isDarkMode ? 'bg-[#0B0B0F]' : 'bg-[#F7F9FC]'}`}>
                    <div className="text-center max-w-xs mx-auto mb-5">
                      <h3 className="font-serif font-black text-lg text-[#F5C542]">Table QR Activation Hub</h3>
                      <p className="text-[10px] text-gray-400 font-sans mt-1">
                        Select a table from 1 to 25 below to simulate scanning a real table sticker and begin ordering instantly!
                      </p>
                    </div>

                    {/* Dynamic QR Configuration Card */}
                    <div className={`mb-5 p-4 rounded-2xl border text-left ${
                      isDarkMode ? 'bg-[#0E1A2B]/80 border-blue-900/30 text-white' : 'bg-white border-gray-200 text-gray-900 shadow-xs'
                    }`}>
                      <div className="flex items-center space-x-2 mb-2">
                        <Globe className="h-4 w-4 text-amber-500" />
                        <h4 className="font-sans font-bold text-xs uppercase tracking-wider">QR Code Target URL Settings</h4>
                      </div>
                      <p className="text-[10px] text-gray-400 leading-relaxed mb-3">
                        Physical phones scanning these QR codes need to reach your deployed website. 
                        Enter your public hosting link (such as <strong>GitHub Pages</strong> or your custom domain) below to update all QR codes.
                      </p>
                      
                      <div className="flex flex-col gap-2">
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={customBaseUrl}
                            onChange={(e) => {
                              setCustomBaseUrl(e.target.value);
                              localStorage.setItem('7waves_custom_qr_base_url', e.target.value);
                            }}
                            placeholder={typeof window !== 'undefined' ? window.location.origin : 'https://the7waves.com'}
                            className={`flex-1 px-3 py-2 text-xs rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono ${
                              isDarkMode 
                                ? 'bg-[#0B0B0F] border-blue-950 text-white placeholder-gray-600' 
                                : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                            }`}
                          />
                          {customBaseUrl && (
                            <button
                              onClick={() => {
                                setCustomBaseUrl('');
                                localStorage.removeItem('7waves_custom_qr_base_url');
                              }}
                              className="px-3 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 text-xs rounded-xl font-sans font-bold transition-all shrink-0 cursor-pointer"
                            >
                              Reset
                            </button>
                          )}
                        </div>
                        
                        <div className="flex flex-wrap items-center justify-between gap-2 mt-1">
                          <span className="text-[9px] text-gray-500">
                            Active QR Base: <code className="text-amber-500 font-mono font-bold">{customBaseUrl || (typeof window !== 'undefined' ? window.location.origin : 'https://the7waves.com')}</code>
                          </span>
                          
                          <button
                            onClick={() => {
                              if (typeof window !== 'undefined') {
                                const origin = window.location.origin;
                                setCustomBaseUrl(origin);
                                localStorage.setItem('7waves_custom_qr_base_url', origin);
                              }
                            }}
                            className="text-[10px] font-sans font-bold text-amber-500 hover:text-amber-400 flex items-center gap-1 cursor-pointer"
                          >
                            <RefreshCw className="h-3 w-3" />
                            <span>Set to Live Origin</span>
                          </button>
                        </div>
                      </div>

                      <div className="mt-3.5 pt-3 border-t border-dashed border-gray-50/10 flex items-start gap-2 text-[9px] text-gray-400">
                        <AlertCircle className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold text-gray-300 block">Deploying to GitHub:</span>
                          To host this app for free on GitHub, click the <strong>Settings Menu</strong> in AI Studio, select <strong>Export to GitHub</strong>, then enable <strong>GitHub Pages</strong> in your repository settings!
                        </div>
                      </div>
                    </div>

                    {/* Highly organized beautiful cards list */}
                    <div className="space-y-4 max-h-[calc(100vh-14rem)] overflow-y-auto pr-1">
                      {Array.from({ length: 25 }, (_, i) => i + 1).map((tableNum) => {
                        const tableIdStr = tableNum.toString();
                        const isTable1 = tableNum === 1;
                        const targetUrl = getDerivedTargetUrl(tableNum);
                        const qrCodeImgSrc = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(targetUrl)}&color=0F172A&bgcolor=FFFFFF&qzone=1`;

                        return (
                          <div 
                            key={tableNum}
                            className={`p-4 rounded-2xl border transition-all duration-200 flex flex-col xs:flex-row items-center justify-between gap-4 ${
                              isTable1
                                ? 'bg-emerald-500/5 border-emerald-500/30 shadow-md ring-2 ring-emerald-500/20'
                                : isDarkMode 
                                  ? 'bg-[#0E1A2B] border-blue-950/40 hover:border-amber-500/30' 
                                  : 'bg-white border-gray-200 shadow-xs hover:border-amber-500/30'
                            }`}
                          >
                            <div className="flex items-center space-x-3 w-full xs:w-auto">
                              {/* QR Image Box */}
                              <div className="p-1.5 bg-white border border-gray-200 rounded-xl w-16 h-16 shrink-0 flex items-center justify-center shadow-xs">
                                <img 
                                  src={qrCodeImgSrc} 
                                  alt={`Table ${tableNum}`} 
                                  className="w-full h-full object-contain"
                                  loading="lazy"
                                />
                              </div>
                              <div className="text-left">
                                <span className={`text-[8px] uppercase tracking-wider font-extrabold ${isTable1 ? 'text-emerald-400' : 'text-amber-500'}`}>
                                  {isTable1 ? '⚡ Open Public Session' : 'Fine Dining Section'}
                                </span>
                                <h4 className="font-serif font-black text-sm text-[#F5C542]">
                                  Dining Table {tableNum < 10 ? `0${tableNum}` : tableNum}
                                </h4>
                                <p className="text-[9px] text-gray-400 mt-0.5 font-sans">
                                  {isTable1 ? 'Official Brand Table QR' : 'Double-check tabletop sticker'}
                                </p>
                              </div>
                            </div>

                            {/* Core Action */}
                            <div className="flex flex-row items-center space-x-2 w-full xs:w-auto">
                              <button
                                onClick={() => {
                                  handleSimulateTableScan(tableIdStr);
                                }}
                                className="flex-1 xs:flex-none px-4 py-2 bg-[#F5C542] hover:bg-amber-500 text-black font-sans font-extrabold text-[10px] uppercase tracking-wider rounded-lg transition-all duration-150 cursor-pointer shadow-xs flex items-center justify-center space-x-1.5"
                              >
                                <QrCode className="h-3 w-3 text-black" />
                                <span>Simulate Table {tableNum} Scan</span>
                              </button>
                              
                              <a
                                href={targetUrl}
                                target="_blank"
                                rel="noreferrer"
                                title="Open Direct Table URL Link"
                                className={`p-2 rounded-lg border transition-all ${
                                  isDarkMode 
                                    ? 'bg-[#0B0B0F] border-blue-950 text-gray-400 hover:text-[#F5C542]' 
                                    : 'bg-gray-50 border-gray-200 text-gray-500 hover:text-[#F5C542]'
                                }`}
                              >
                                <Compass className="h-3.5 w-3.5" />
                              </a>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* C. THE STORY TAB */}
                {welcomeTab === 'about' && (
                  <div className={`flex-1 p-5 max-w-md mx-auto space-y-6 ${isDarkMode ? 'bg-[#0B0B0F]' : 'bg-[#F7F9FC]'}`}>
                    <div className="text-center max-w-xs mx-auto">
                      <h3 className="font-serif font-black text-lg text-[#F5C542]">The Beachfront Story</h3>
                      <p className="text-[10px] text-gray-400 font-sans mt-1">
                        How beachfront architecture meets state-of-the-art tech.
                      </p>
                    </div>

                    <div className={`p-4 rounded-2xl border space-y-4 text-xs leading-relaxed ${
                      isDarkMode ? 'bg-[#0E1A2B] border-blue-950/40 text-gray-300' : 'bg-white border-gray-100 text-gray-600'
                    }`}>
                      <p>
                        Established with a grand design to blend modern contactless hospitality with traditional culinary mastery, <strong className="text-[#F5C542]">The 7 Waves Resto & Cafe</strong> overlooks the spectacular beach shores.
                      </p>
                      
                      <div className="border-l-2 border-amber-500 pl-3 italic text-amber-500/90 text-[11px]">
                        "Seven majestic waves representing seven global flavor trends: Royal North Indian, Coastal Tandoori, Elegant Continental, Artisan Desserts, Craft Coffee, Handpicked Mocktails, and Smart Beachside Table Tech."
                      </div>

                      <p>
                        Our technology allows guests to sit at any of our 25 luxury tables, scan the tabletop QR placard, review real allergen details, state exact cooking preferences for chefs, and monitor prep updates live from the seat.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-center">
                      <div className={`p-3 rounded-xl border ${
                        isDarkMode ? 'bg-[#0E1A2B]/60 border-blue-950/30' : 'bg-white border-gray-100'
                      }`}>
                        <span className="block text-[#F5C542] font-serif font-black text-lg">11 AM - 11 PM</span>
                        <span className="text-[8px] text-gray-400 uppercase tracking-widest block mt-0.5">Kitchen Hours</span>
                      </div>
                      <div className={`p-3 rounded-xl border ${
                        isDarkMode ? 'bg-[#0E1A2B]/60 border-blue-950/30' : 'bg-white border-gray-100'
                      }`}>
                        <span className="block text-[#F5C542] font-serif font-black text-lg">25 Tables</span>
                        <span className="text-[8px] text-gray-400 uppercase tracking-widest block mt-0.5">Beachside Seats</span>
                      </div>
                    </div>
                  </div>
                )}

              </div>

              {/* Footer controls & info */}
              <footer className={`relative z-10 px-5 py-4 border-t flex flex-col items-center space-y-3.5 transition-colors duration-200 ${
                welcomeTab === 'hero' 
                  ? 'border-white/5 bg-black/50 backdrop-blur-sm' 
                  : isDarkMode 
                    ? 'border-blue-950 bg-[#0E1A2B]/90' 
                    : 'border-gray-100 bg-white'
              }`}>
                {/* Theme preferences */}
                <div className="flex justify-center space-x-3">
                  <button
                    onClick={() => setIsDarkMode(false)}
                    className={`text-[9px] px-3 py-1 rounded-full font-bold uppercase tracking-wider transition-all border ${
                      !isDarkMode ? 'bg-[#F5C542] text-black border-[#F5C542]' : 'text-gray-400 border-white/10 hover:border-white/30'
                    }`}
                  >
                    Luxury Light
                  </button>
                  <button
                    onClick={() => setIsDarkMode(true)}
                    className={`text-[9px] px-3 py-1 rounded-full font-bold uppercase tracking-wider transition-all border ${
                      isDarkMode ? 'bg-[#F5C542] text-black border-[#F5C542]' : 'text-gray-400 border-white/10 hover:border-white/30'
                    }`}
                  >
                    Luxury Dark
                  </button>
                </div>

                <div className={`text-[8px] font-sans tracking-widest uppercase ${
                  welcomeTab === 'hero' ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  © The 7 Waves Resto & Cafe • Beachfront Table Hub
                </div>
              </footer>
            </motion.div>
          )}

          {/* 2. QR ENTRY / CONFIRMED LOGIN SCREEN */}
          {currentView === 'table_confirmed' && tableId && (
            <motion.div
              key="table_confirmed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <QREntryScreen
                tableId={tableId}
                onStartOrdering={() => setCurrentView('menu')}
                isDarkMode={isDarkMode}
              />
            </motion.div>
          )}

          {/* 3. HOME / FOOD MENU VIEW */}
          {currentView === 'menu' && (
            <motion.div
              key="menu"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col min-h-screen"
            >
              <Header
                tableId={tableId}
                cartCount={cartCount}
                onOpenCart={() => setCurrentView('cart')}
                onOpenAdmin={() => setCurrentView('admin')}
                currentView={currentView}
                isDarkMode={isDarkMode}
                onToggleDarkMode={handleToggleDarkMode}
              />

              <CategoryTabs
                selectedCategory={selectedCategory}
                onSelectCategory={(cat) => setSelectedCategory(cat)}
                isDarkMode={isDarkMode}
              />

              {/* Food Catalog Grid */}
              <div className={`flex-1 px-4 py-5 space-y-4.5 pb-32 transition-colors duration-300 ${
                isDarkMode ? 'bg-[#0B0B0F]' : 'bg-[#F7F9FC]'
              }`}>
                <div className="max-w-md mx-auto space-y-4">
                  
                  {/* Search and Advanced Filters Area */}
                  <div className={`p-4 rounded-2xl border transition-all duration-300 ${
                    isDarkMode 
                      ? 'bg-[#0E1A2B]/40 border-blue-900/30' 
                      : 'bg-white border-gray-100 shadow-sm'
                  }`}>
                    {/* Search Bar Input */}
                    <div className="relative flex items-center">
                      <Search className="absolute left-3.5 h-4 w-4 text-gray-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search truffle, lobster, paneer, matcha..."
                        className={`w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                          isDarkMode 
                            ? 'bg-[#0B0B0F] border-blue-900/30 text-white placeholder-gray-500' 
                            : 'bg-gray-50 border-gray-150 text-gray-800 placeholder-gray-400'
                        }`}
                      />
                    </div>

                    {/* Quick Filters Row */}
                    <div className="flex items-center space-x-2 mt-3.5">
                      <Filter className="h-3 w-3 text-amber-500" />
                      <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Quick Filters:</span>
                      
                      {/* Veg only filter */}
                      <button
                        onClick={() => setFilterVegOnly(!filterVegOnly)}
                        className={`text-[10px] px-2.5 py-1 rounded-md font-bold border transition-all cursor-pointer ${
                          filterVegOnly
                            ? 'bg-emerald-600 border-emerald-700 text-white'
                            : isDarkMode
                              ? 'bg-[#0B0B0F] border-blue-900/20 text-gray-400 hover:text-white'
                              : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        Veg 🌱
                      </button>

                      {/* Bestseller filter */}
                      <button
                        onClick={() => setFilterBestsellerOnly(!filterBestsellerOnly)}
                        className={`text-[10px] px-2.5 py-1 rounded-md font-bold border transition-all cursor-pointer ${
                          filterBestsellerOnly
                            ? 'bg-amber-500 border-amber-600 text-white'
                            : isDarkMode
                              ? 'bg-[#0B0B0F] border-blue-900/20 text-gray-400 hover:text-white'
                              : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        Bestseller ⭐
                      </button>
                    </div>
                  </div>

                  {/* Category Title Header */}
                  <div className="flex justify-between items-baseline pt-2">
                    <h2 className={`font-serif font-black text-xl capitalize ${isDarkMode ? 'text-white' : 'text-gray-950'}`}>
                      {selectedCategory === 'mains' ? 'Main Courses' : selectedCategory}
                    </h2>
                    <span className="text-xs text-gray-400 font-sans">
                      {filteredMenuItems.length} artisanal selection{filteredMenuItems.length !== 1 ? 's' : ''}
                    </span>
                  </div>

                  {/* Menu Items Grid */}
                  {filteredMenuItems.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {filteredMenuItems.map((item) => {
                        const cartItem = cart.find((c) => c.menuItem.id === item.id);
                        const quantity = cartItem ? cartItem.quantity : 0;

                        return (
                          <FoodCard
                            key={item.id}
                            item={item}
                            quantityInCart={quantity}
                            onIncrement={() => handleAddToCart(item, quantity + 1, cartItem?.spiceLevel, cartItem?.customNotes)}
                            onDecrement={() => handleAddToCart(item, Math.max(0, quantity - 1), cartItem?.spiceLevel, cartItem?.customNotes)}
                            onClick={() => setSelectedDish(item)}
                            isDarkMode={isDarkMode}
                          />
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-xs text-gray-500">No delicacies match your filters. Try clearing filters or search.</p>
                      <button
                        onClick={() => {
                          setSearchQuery('');
                          setFilterVegOnly(false);
                          setFilterBestsellerOnly(false);
                        }}
                        className="mt-3 text-xs text-amber-500 font-bold underline cursor-pointer"
                      >
                        Reset All Filters
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Floating Review Cart Button */}
              {cartCount > 0 && (
                <div className={`fixed bottom-0 inset-x-0 z-40 border-t py-3.5 px-6 max-w-md mx-auto shadow-[0_-8px_30px_rgb(0,0,0,0.06)] ${
                  isDarkMode ? 'bg-[#0E1A2B]/95 border-blue-950' : 'bg-white/95 border-gray-100'
                }`}>
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setCurrentView('cart')}
                    className="w-full bg-amber-500 text-white font-sans font-bold text-sm py-3.5 px-5 rounded-full shadow-lg flex items-center justify-between hover:bg-amber-600 transition-colors duration-200 cursor-pointer"
                  >
                    <span className="flex items-center space-x-2">
                      <span className="w-6 h-6 rounded-full bg-white/20 text-white text-[11px] font-bold flex items-center justify-center">
                        {cartCount}
                      </span>
                      <span>Item{cartCount > 1 ? 's' : ''} Selected</span>
                    </span>
                    <span className="font-serif font-black text-white">
                      View Table Order • ₹{cart.reduce((acc, item) => acc + item.menuItem.price * item.quantity, 0)}
                    </span>
                  </motion.button>
                </div>
              )}

              {/* Active Order Tracker Shortcut Badge */}
              {activeOrder && cartCount === 0 && (
                <div className="fixed bottom-4 inset-x-0 z-40 max-w-md mx-auto px-6 text-center">
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setCurrentView('order_tracking')}
                    className="inline-flex items-center space-x-2 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-sans font-bold text-xs py-2.5 px-5 rounded-full shadow-md hover:shadow-lg cursor-pointer"
                  >
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    <span>Track Active Order #{activeOrder.id}</span>
                  </motion.button>
                </div>
              )}
            </motion.div>
          )}

          {/* 4. CART & BILLING VIEW */}
          {currentView === 'cart' && (
            <motion.div
              key="cart"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <CartView
                cart={cart}
                tableId={tableId}
                onIncrement={handleIncrementCart}
                onDecrement={handleDecrementCart}
                onRemoveItem={handleRemoveCartItem}
                onUpdateCustomNotes={handleUpdateCartItemNotes}
                onPlaceOrder={handlePlaceOrder}
                onBackToMenu={() => setCurrentView('menu')}
                isDarkMode={isDarkMode}
              />
            </motion.div>
          )}

          {/* 5. ORDER TRACKING VIEW */}
          {currentView === 'order_tracking' && (
            <motion.div
              key="order_tracking"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <OrderTracking
                order={activeOrder}
                onBackToMenu={() => setCurrentView('menu')}
                onAdvanceStatus={handleAdvanceStatus}
                isDarkMode={isDarkMode}
              />
            </motion.div>
          )}

          {/* 6. ADMIN TABLE QR GENERATOR HUB */}
          {currentView === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <QRGenerator
                onSimulateTableScan={handleSimulateTableScan}
                activeTableId={tableId}
                onClose={() => setCurrentView(tableId ? 'menu' : 'welcome')}
                isDarkMode={isDarkMode}
                customBaseUrl={customBaseUrl}
                onUpdateCustomBaseUrl={(url) => {
                  setCustomBaseUrl(url);
                  localStorage.setItem('7waves_custom_qr_base_url', url);
                }}
              />
            </motion.div>
          )}

        </AnimatePresence>

        {/* --- DUMP / RESET BUTTON FOR TESTING CONVENIENCE --- */}
        {tableId && currentView !== 'welcome' && currentView !== 'admin' && (
          <div className="absolute top-20 right-4 z-40">
            <button
              onClick={handleLogoutTable}
              className={`p-1.5 rounded-full backdrop-blur-xs text-red-500 hover:text-red-400 border shadow-sm transition-all text-xs flex items-center space-x-1 cursor-pointer ${
                isDarkMode ? 'bg-[#0E1A2B]/90 border-blue-900/30' : 'bg-white/90 border-gray-100'
              }`}
              title="Clear Session"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span className="text-[10px] font-sans font-bold pr-1">Exit</span>
            </button>
          </div>
        )}

        {/* --- DISH DETAIL MODAL (BOTTOM SHEET OVERLAY) --- */}
        <AnimatePresence>
          {selectedDish && (
            <DishDetail
              item={selectedDish}
              onClose={() => setSelectedDish(null)}
              onAddToCart={handleAddToCart}
              currentCartQuantity={cart.find((c) => c.menuItem.id === selectedDish.id)?.quantity || 0}
              isDarkMode={isDarkMode}
            />
          )}
        </AnimatePresence>

        {/* --- LIVE QR CAMERA SCANNER MODAL --- */}
        <AnimatePresence>
          {isScannerOpen && (
            <QRScannerModal
              onScanSuccess={(scannedTableId) => {
                setIsScannerOpen(false);
                handleSimulateTableScan(scannedTableId);
              }}
              onClose={() => setIsScannerOpen(false)}
              isDarkMode={isDarkMode}
            />
          )}
        </AnimatePresence>

        {/* --- LUXURIOUS BRAND CONTACT MODAL --- */}
        <AnimatePresence>
          {showContactModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
              <div className="absolute inset-0 cursor-pointer" onClick={() => setShowContactModal(false)} />
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className={`relative w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl z-10 border transition-all duration-300 p-6 ${
                  isDarkMode 
                    ? 'bg-[#0E1A2B] text-white border-blue-900/40' 
                    : 'bg-white text-gray-900 border-gray-100'
                }`}
              >
                <button
                  onClick={() => setShowContactModal(false)}
                  className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-white/10 text-gray-400 transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>

                <div className="text-center space-y-4 pt-3">
                  <div className="w-12 h-12 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto text-amber-500">
                    <Sparkles className="h-6 w-6 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="font-serif font-black text-xl text-[#F5C542]">The 7 Waves</h3>
                    <p className="text-[10px] text-gray-400 font-sans uppercase tracking-widest font-bold">
                      Fine Dining Resto & Cafe
                    </p>
                  </div>

                  <div className={`p-4 rounded-2xl text-left text-xs space-y-3.5 border ${
                    isDarkMode ? 'bg-[#0B0B0F]/60 border-blue-950' : 'bg-gray-50 border-gray-100'
                  }`}>
                    <div>
                      <span className="block font-sans font-bold text-gray-400 uppercase tracking-wider text-[9px] mb-0.5">
                        Address Location
                      </span>
                      <p className="font-medium leading-relaxed">
                        7 Waves Cliff Road, Beachfront Boulevard, Mumbai, MH, India
                      </p>
                    </div>

                    <div className="border-t border-dashed border-gray-50/10 pt-3">
                      <span className="block font-sans font-bold text-gray-400 uppercase tracking-wider text-[9px] mb-0.5">
                        Telephone Helpline
                      </span>
                      <p className="font-bold text-sm text-[#F5C542]">
                        +91 (22) 7WAVES-900
                      </p>
                      <p className="text-[10px] text-gray-400 mt-0.5">
                        For catering, feedback, or custom events.
                      </p>
                    </div>
                  </div>

                  <a
                    href="tel:+912279283790"
                    className="w-full bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-white font-sans font-bold text-xs py-3 rounded-full shadow-md flex items-center justify-center space-x-2 transition-all cursor-pointer"
                  >
                    <span>Dial Restaurant Direct</span>
                  </a>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}

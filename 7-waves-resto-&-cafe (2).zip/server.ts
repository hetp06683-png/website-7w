import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { db } from './server/db';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Make sure Express can parse large payloads for base64 image uploading
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // Create local uploads directory for custom admin menu image uploading
  const uploadsDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  // Serve custom uploaded files statically
  app.use('/uploads', express.static(uploadsDir));

  // --- REAL-TIME SERVER-SENT EVENTS (SSE) EVENT BROADCASTER ---
  let sseClients: any[] = [];

  app.get('/api/orders/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Add this response object to clients list
    sseClients.push(res);

    // Send connection established signal
    res.write(`data: ${JSON.stringify({ type: 'connected', timestamp: Date.now() })}\n\n`);

    // Keep connection alive with heartbeat pings every 20 seconds
    const heartbeat = setInterval(() => {
      res.write(`data: ${JSON.stringify({ type: 'heartbeat' })}\n\n`);
    }, 20000);

    req.on('close', () => {
      clearInterval(heartbeat);
      sseClients = sseClients.filter(client => client !== res);
    });
  });

  const broadcastToKitchenAndCustomer = (type: string, data: any) => {
    const payload = JSON.stringify({ type, data });
    sseClients.forEach(client => {
      try {
        client.write(`data: ${payload}\n\n`);
      } catch (err) {
        console.error('SSE send failure', err);
      }
    });
  };

  // --- API ROUTE ENDPOINTS ---

  // 1. GET RESTAURANTS
  app.get('/api/restaurants', (req, res) => {
    res.json(db.restaurants);
  });

  // 2. GET TABLES
  app.get('/api/tables', (req, res) => {
    res.json(db.tables);
  });

  // 3. GET DYNAMIC MENU ITEMS
  app.get('/api/menu_items', (req, res) => {
    res.json(db.menu_items);
  });

  // 4. ADD MENU ITEM (ADMIN)
  app.post('/api/menu_items', (req, res) => {
    try {
      const { name, price, image, desc, category, ingredients, isVeg, isBestseller, rating, prepTime } = req.body;
      if (!name || price === undefined || !category) {
        return res.status(400).json({ error: 'Name, price and category are required' });
      }

      const newItem = db.addMenuItem({
        name,
        price: Number(price),
        image: image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=600&auto=format&fit=crop',
        desc: desc || '',
        category,
        ingredients: Array.isArray(ingredients) ? ingredients : [],
        isVeg: !!isVeg,
        isBestseller: !!isBestseller,
        rating: Number(rating) || 4.5,
        prepTime: prepTime || '15 mins',
        available: true
      });

      res.status(201).json(newItem);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 5. UPDATE MENU ITEM (ADMIN)
  app.put('/api/menu_items/:id', (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;

      if (updates.price !== undefined) {
        updates.price = Number(updates.price);
      }
      if (updates.rating !== undefined) {
        updates.rating = Number(updates.rating);
      }

      const updated = db.updateMenuItem(id, updates);
      if (!updated) {
        return res.status(404).json({ error: 'Menu item not found' });
      }

      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 6. TOGGLE AVAILABILITY (ADMIN)
  app.patch('/api/menu_items/:id/toggle', (req, res) => {
    try {
      const { id } = req.params;
      const updated = db.toggleMenuItemAvailability(id);
      if (!updated) {
        return res.status(404).json({ error: 'Menu item not found' });
      }
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 7. PLACE SECURE RESTAURANT ORDER
  app.post('/api/orders', (req, res) => {
    try {
      const { tableId, items } = req.body;

      if (!tableId || !items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Valid tableId and non-empty items array are required' });
      }

      // Format items to match db expectation
      const orderItemsInput = items.map((item: any) => ({
        menuItemId: item.menuItem.id,
        quantity: item.quantity,
        spiceLevel: item.spiceLevel || 'Medium',
        customNotes: item.customNotes || ''
      }));

      const createdOrder = db.createOrder({
        tableId: tableId.toString(),
        items: orderItemsInput
      });

      // Broadcast new order to live kitchen dashboard instantly!
      broadcastToKitchenAndCustomer('new_order', createdOrder);

      res.status(201).json(createdOrder);
    } catch (err: any) {
      console.error('Order placement failed:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // 8. GET ALL ORDERS (KITCHEN & ADMIN MONITOR)
  app.get('/api/orders', (req, res) => {
    res.json(db.getAllPopulatedOrders());
  });

  // 9. GET SPECIFIC ORDER STATUS
  app.get('/api/orders/:id', (req, res) => {
    const order = db.getPopulatedOrder(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    res.json(order);
  });

  // 10. UPDATE ORDER STATUS (KITCHEN STAFF CONTROL)
  app.patch('/api/orders/:id/status', (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      const allowedStatuses = ['pending', 'received', 'preparing', 'almost_ready', 'served', 'cancelled'];
      if (!allowedStatuses.includes(status)) {
        return res.status(400).json({ error: `Invalid status. Must be one of ${allowedStatuses.join(', ')}` });
      }

      const updated = db.updateOrderStatus(id, status);
      if (!updated) {
        return res.status(404).json({ error: 'Order not found' });
      }

      const populatedOrder = db.getPopulatedOrder(id);

      // Broadcast order status change to customer & kitchen in real-time!
      broadcastToKitchenAndCustomer('status_update', populatedOrder);

      res.json(populatedOrder);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 11. BASE64 IMAGE UPLOAD ENDPOINT (FOR ADMIN PANEL IMAGE UPLOADS)
  app.post('/api/upload', (req, res) => {
    const { imageBase64 } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'No image base64 data provided' });
    }

    try {
      const matches = imageBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
      let base64Data = imageBase64;
      let extension = '.jpg';

      if (matches && matches.length === 3) {
        base64Data = matches[2];
        const mimeType = matches[1];
        if (mimeType.includes('png')) extension = '.png';
        else if (mimeType.includes('gif')) extension = '.gif';
        else if (mimeType.includes('webp')) extension = '.webp';
      }

      const uniqueFileName = `item_${Date.now()}${extension}`;
      const filePath = path.join(uploadsDir, uniqueFileName);

      fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));

      res.json({ imageUrl: `/uploads/${uniqueFileName}` });
    } catch (err: any) {
      console.error('Image write failed', err);
      res.status(500).json({ error: 'Failed to write uploaded image' });
    }
  });

  // --- VITE DEV AND BUILD HANDLERS ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[7 WAVES SERVER] running on http://localhost:${PORT}`);
  });
}

startServer();

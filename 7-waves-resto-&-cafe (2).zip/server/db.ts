import { MenuItem, CartItem, Order } from '../src/types';
import { MENU_ITEMS } from '../src/data/menu';

export interface DBRestaurant {
  id: string;
  name: string;
  desc: string;
  logo: string;
}

export interface DBTable {
  id: string;
  restaurantId: string;
  status: 'active' | 'inactive';
}

export interface DBMenuItem {
  id: string;
  name: string;
  price: number;
  image: string;
  desc: string;
  category: string;
  ingredients: string[];
  isVeg: boolean;
  isBestseller: boolean;
  rating: number;
  prepTime: string;
  available: boolean;
}

export interface DBOrder {
  id: string;
  tableId: string;
  restaurantId: string;
  subtotal: number;
  gst: number;
  serviceCharge: number;
  total: number;
  status: 'pending' | 'received' | 'preparing' | 'almost_ready' | 'served' | 'cancelled';
  timestamp: string;
}

export interface DBOrderItem {
  id: string;
  orderId: string;
  menuItemId: string;
  quantity: number;
  priceAtOrder: number;
  spiceLevel: string;
  customNotes: string;
}

class RelationalDatabase {
  public restaurants: DBRestaurant[] = [];
  public tables: DBTable[] = [];
  public menu_items: DBMenuItem[] = [];
  public orders: DBOrder[] = [];
  public order_items: DBOrderItem[] = [];

  constructor() {
    this.seed();
  }

  private seed() {
    // 1. Seed Restaurant
    const restaurantId = 'r1';
    this.restaurants.push({
      id: restaurantId,
      name: 'The 7 Waves',
      desc: "Mumbai's Finest Beachfront Dining",
      logo: ''
    });

    // 2. Seed Tables (1 - 25)
    for (let i = 1; i <= 25; i++) {
      this.tables.push({
        id: i.toString(),
        restaurantId,
        status: 'active'
      });
    }

    // 3. Seed Menu Items
    MENU_ITEMS.forEach((item) => {
      this.menu_items.push({
        id: item.id,
        name: item.name,
        price: item.price,
        image: item.image,
        desc: item.desc || '',
        category: item.category,
        ingredients: item.ingredients || [],
        isVeg: !!item.isVeg,
        isBestseller: !!item.isBestseller,
        rating: item.rating || 4.5,
        prepTime: item.prepTime || '15 mins',
        available: true // Default enabled
      });
    });
  }

  // Helper: Find menu item by ID
  public getMenuItem(id: string): DBMenuItem | undefined {
    return this.menu_items.find(item => item.id === id);
  }

  // Helper: Add menu item
  public addMenuItem(item: Omit<DBMenuItem, 'id'>): DBMenuItem {
    const newId = 'm_' + Math.floor(10000 + Math.random() * 90000).toString();
    const newItem: DBMenuItem = { ...item, id: newId };
    this.menu_items.push(newItem);
    return newItem;
  }

  // Helper: Update menu item
  public updateMenuItem(id: string, updates: Partial<DBMenuItem>): DBMenuItem | undefined {
    const itemIdx = this.menu_items.findIndex(item => item.id === id);
    if (itemIdx === -1) return undefined;
    this.menu_items[itemIdx] = { ...this.menu_items[itemIdx], ...updates };
    return this.menu_items[itemIdx];
  }

  // Helper: Delete or toggle menu item
  public toggleMenuItemAvailability(id: string): DBMenuItem | undefined {
    const item = this.getMenuItem(id);
    if (item) {
      item.available = !item.available;
    }
    return item;
  }

  // Helper: Get orders along with populated items
  public getPopulatedOrder(orderId: string) {
    const order = this.orders.find(o => o.id === orderId);
    if (!order) return null;

    const items = this.order_items
      .filter(oi => oi.orderId === orderId)
      .map(oi => {
        const menuItem = this.getMenuItem(oi.menuItemId);
        return {
          id: oi.id,
          menuItemId: oi.menuItemId,
          quantity: oi.quantity,
          priceAtOrder: oi.priceAtOrder,
          spiceLevel: oi.spiceLevel,
          customNotes: oi.customNotes,
          menuItem: menuItem || {
            id: oi.menuItemId,
            name: 'Deleted Item',
            price: oi.priceAtOrder,
            image: '',
            desc: '',
            category: 'unknown',
            ingredients: [],
            isVeg: false,
            isBestseller: false,
            rating: 0,
            prepTime: '',
            available: false
          }
        };
      });

    return {
      ...order,
      items
    };
  }

  // Helper: Get all orders populated
  public getAllPopulatedOrders() {
    return this.orders.map(order => this.getPopulatedOrder(order.id)).filter(Boolean);
  }

  // Helper: Create complete Order
  public createOrder(data: {
    tableId: string;
    items: Array<{
      menuItemId: string;
      quantity: number;
      spiceLevel?: string;
      customNotes?: string;
    }>;
  }): any {
    // Validate table existence
    const tableExists = this.tables.some(t => t.id === data.tableId);
    if (!tableExists) {
      throw new Error(`Table with ID ${data.tableId} does not exist.`);
    }

    // Calculate subtotal, gst, service charge, and total
    let subtotal = 0;
    const orderId = Math.floor(1000 + Math.random() * 9000).toString();

    const createdItems: DBOrderItem[] = [];

    data.items.forEach(item => {
      const menuItem = this.getMenuItem(item.menuItemId);
      if (!menuItem) {
        throw new Error(`Menu item with ID ${item.menuItemId} does not exist.`);
      }

      const itemPrice = menuItem.price;
      subtotal += itemPrice * item.quantity;

      createdItems.push({
        id: 'oi_' + Math.floor(10000 + Math.random() * 90000).toString(),
        orderId,
        menuItemId: item.menuItemId,
        quantity: item.quantity,
        priceAtOrder: itemPrice,
        spiceLevel: item.spiceLevel || 'Medium',
        customNotes: item.customNotes || ''
      });
    });

    const gst = Math.round(subtotal * 0.05);
    const serviceCharge = Math.round(subtotal * 0.05);
    const total = subtotal + gst + serviceCharge;

    const newOrder: DBOrder = {
      id: orderId,
      tableId: data.tableId,
      restaurantId: 'r1',
      subtotal,
      gst,
      serviceCharge,
      total,
      status: 'pending', // Starts as pending as per requirements
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    // Save order & items with proper relations
    this.orders.push(newOrder);
    this.order_items.push(...createdItems);

    return this.getPopulatedOrder(orderId);
  }

  // Helper: Update order status
  public updateOrderStatus(orderId: string, status: DBOrder['status']): DBOrder | undefined {
    const order = this.orders.find(o => o.id === orderId);
    if (order) {
      order.status = status;
    }
    return order;
  }
}

export const db = new RelationalDatabase();

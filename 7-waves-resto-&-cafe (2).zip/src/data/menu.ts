import { MenuItem } from '../types';

export const MENU_ITEMS: MenuItem[] = [
  // STARTERS
  {
    id: 's1',
    name: 'Truffle Edamame Gyoza',
    price: 549,
    image: 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?q=80&w=600&auto=format&fit=crop',
    desc: 'Pan-seared gyoza with minced edamame, white truffle oil, and dynamic soy glaze.',
    category: 'starters',
    ingredients: ['Edamame', 'Truffle Oil', 'Gyoza Wrapper', 'Ginger', 'Chives', 'Soy Glaze'],
    isVeg: true,
    isBestseller: true,
    rating: 4.8,
    prepTime: '12 mins'
  },
  {
    id: 's2',
    name: 'Crispy Avocado Tartare',
    price: 499,
    image: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?q=80&w=600&auto=format&fit=crop',
    desc: 'Layered fresh Haas avocado, cucumber, citrus-chili vinaigrette, served on crisp lotus root chips.',
    category: 'starters',
    ingredients: ['Avocado', 'Cucumber', 'Citrus Vinaidrette', 'Lotus Root Chips', 'Microgreens'],
    isVeg: true,
    isBestseller: false,
    rating: 4.6,
    prepTime: '10 mins'
  },
  {
    id: 's3',
    name: 'Smoked Paneer Tikka Carpaccio',
    price: 499,
    image: 'https://images.unsplash.com/photo-1600891964599-f61ba0e24092?q=80&w=600&auto=format&fit=crop',
    desc: 'Spicy grilled premium paneer infused with hickory smoke, mint-infused yogurt emulsion, and gold leaf dust.',
    category: 'starters',
    ingredients: ['Paneer', 'Hickory Smoke', 'Greek Yogurt', 'Mint', 'Kashmiri Chili', 'Kasturi Methi'],
    spicinessLevel: true,
    isVeg: true,
    isBestseller: true,
    rating: 4.9,
    prepTime: '15 mins'
  },

  // MAIN COURSE
  {
    id: 'm1',
    name: 'Saffron Wild Mushroom Risotto',
    price: 799,
    image: 'https://images.unsplash.com/photo-1476124369491-e7addf5db371?q=80&w=600&auto=format&fit=crop',
    desc: 'Creamy Acquerello Carnaroli rice cooked with Spanish saffron, topped with butter-glazed wild chanterelles and Parmigiano-Reggiano.',
    category: 'mains',
    ingredients: ['Carnaroli Rice', 'Saffron', 'Chanterelle Mushrooms', 'Parmigiano-Reggiano', 'White Wine'],
    isVeg: true,
    isBestseller: true,
    rating: 4.9,
    prepTime: '18 mins'
  },
  {
    id: 'm2',
    name: 'Charred Asparagus & Burrata Gnocchi',
    price: 749,
    image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?q=80&w=600&auto=format&fit=crop',
    desc: 'Handmade potato gnocchi tossed in creamy pesto, roasted organic asparagus spears, topped with creamy Puglia burrata.',
    category: 'mains',
    ingredients: ['Potato Gnocchi', 'Puglia Burrata', 'Basil Pesto', 'Asparagus', 'Pine Nuts'],
    isVeg: true,
    isBestseller: false,
    rating: 4.7,
    prepTime: '14 mins'
  },

  // SEAFOOD
  {
    id: 'sf1',
    name: '7 Waves Grilled Lobster Tail',
    price: 1899,
    image: 'https://images.unsplash.com/photo-1559742811-824289511f48?q=80&w=600&auto=format&fit=crop',
    desc: 'Flame-grilled Caribbean lobster tail basted with roasted garlic herb butter, lemon dust, and served with dynamic sea fennel.',
    category: 'seafood',
    ingredients: ['Lobster Tail', 'Garlic Butter', 'Sea Fennel', 'Lemon', 'Smoked Sea Salt'],
    isVeg: false,
    isBestseller: true,
    rating: 4.9,
    prepTime: '22 mins'
  },
  {
    id: 'sf2',
    name: 'Pan-Seared Golden Sea Bass',
    price: 1249,
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?q=80&w=600&auto=format&fit=crop',
    desc: 'Crispy skin Chilean sea bass resting on saffron potato foam, roasted heirloom tomatoes, drizzled with chive oil.',
    category: 'seafood',
    ingredients: ['Sea Bass', 'Saffron Potato Foam', 'Heirloom Tomatoes', 'Chive Oil', 'Capers'],
    isVeg: false,
    isBestseller: false,
    rating: 4.8,
    prepTime: '20 mins'
  },
  {
    id: 'sf3',
    name: 'Garlic Butter Prawns',
    price: 899,
    image: 'https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?q=80&w=600&auto=format&fit=crop',
    desc: 'Premium king prawns tossed in dynamic herb-infused butter, garlic cloves, served with charred artisan sourdough.',
    category: 'seafood',
    ingredients: ['King Prawns', 'Artisan Butter', 'Fresh Garlic', 'Herbs', 'Sourdough Bread'],
    spicinessLevel: true,
    isVeg: false,
    isBestseller: true,
    rating: 4.8,
    prepTime: '15 mins'
  },

  // DRINKS
  {
    id: 'd1',
    name: 'Golden Wave Cold Brew',
    price: 329,
    image: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?q=80&w=600&auto=format&fit=crop',
    desc: 'Signature single-origin cold brew topped with premium vanilla cream foam, finished with a dash of edible 24k gold flakes.',
    category: 'drinks',
    ingredients: ['Arabica Cold Brew', 'Vanilla Sweet Cream', 'Gold Flakes'],
    isVeg: true,
    isBestseller: false,
    rating: 4.7,
    prepTime: '5 mins'
  },
  {
    id: 'd2',
    name: 'Ocean Fog Mocktail',
    price: 349,
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=600&auto=format&fit=crop',
    desc: 'An exotic sparkling blue lagoon mocktail with blue curaçao, fresh kaffir lime, botanical mint extract, served with a dramatic dry ice fog effect.',
    category: 'drinks',
    ingredients: ['Blue Curaçao', 'Kaffir Lime', 'Mint Extract', 'Club Soda', 'Botanical Syrup'],
    isVeg: true,
    isBestseller: true,
    rating: 4.9,
    prepTime: '6 mins'
  },
  {
    id: 'd3',
    name: 'Smoked Rosemary Citrus Tonic',
    price: 299,
    image: 'https://images.unsplash.com/photo-1536935338788-846bb9981813?q=80&w=600&auto=format&fit=crop',
    desc: 'Hand-pressed ruby grapefruit juice, artisanal tonic, rosemary sprig torched at your table for complex herbal aromatics.',
    category: 'drinks',
    ingredients: ['Ruby Grapefruit', 'Torched Rosemary', 'Artisan Tonic', 'Juniper Infusion'],
    isVeg: true,
    isBestseller: false,
    rating: 4.6,
    prepTime: '7 mins'
  },

  // DESSERTS
  {
    id: 'de1',
    name: 'Golden Waves Tiramisu Sphere',
    price: 499,
    image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?q=80&w=600&auto=format&fit=crop',
    desc: 'Tempered chocolate sphere filled with creamy espresso mascarpone mousse and sponge soaked in single-origin cold brew, melted at table with hot dark chocolate sauce.',
    category: 'desserts',
    ingredients: ['Mascarpone Mousse', 'Espresso Sponge', 'Premium Dark Chocolate', 'Edible Gold Dust'],
    isVeg: true,
    isBestseller: true,
    rating: 4.9,
    prepTime: '10 mins'
  },
  {
    id: 'de2',
    name: 'Deconstructed Matcha Forest Tart',
    price: 449,
    image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?q=80&w=600&auto=format&fit=crop',
    desc: 'Uji matcha custard, almond sable soil crumble, freeze-dried wild raspberries, and velvety coconut snow.',
    category: 'desserts',
    ingredients: ['Uji Matcha', 'Almond Sable', 'Wild Raspberries', 'Coconut Milk'],
    isVeg: true,
    isBestseller: false,
    rating: 4.8,
    prepTime: '12 mins'
  }
];

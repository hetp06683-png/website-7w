import React from 'react';
import { Trash2, Plus, Minus, ArrowLeft, ShieldCheck, Waves, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';
import { CartItem } from '../types';

interface CartViewProps {
  cart: CartItem[];
  tableId: string | null;
  onIncrement: (index: number) => void;
  onDecrement: (index: number) => void;
  onRemoveItem: (index: number) => void;
  onUpdateCustomNotes?: (index: number, notes: string) => void;
  onPlaceOrder: () => void;
  onBackToMenu: () => void;
  isDarkMode?: boolean;
}

export default function CartView({
  cart,
  tableId,
  onIncrement,
  onDecrement,
  onRemoveItem,
  onUpdateCustomNotes,
  onPlaceOrder,
  onBackToMenu,
  isDarkMode = false
}: CartViewProps) {
  const [editingIndex, setEditingIndex] = React.useState<number | null>(null);
  const [tempNotes, setTempNotes] = React.useState<string>('');
  const [generalInstructions, setGeneralInstructions] = React.useState<string>(() => {
    return localStorage.getItem('7waves_general_instructions') || '';
  });

  const handleSaveGeneralInstructions = (val: string) => {
    setGeneralInstructions(val);
    localStorage.setItem('7waves_general_instructions', val);
  };

  const subtotal = cart.reduce((acc, item) => acc + item.menuItem.price * item.quantity, 0);
  const gst = Math.round(subtotal * 0.05); // 5% GST
  const serviceCharge = Math.round(subtotal * 0.05); // 5% Service Charge
  const total = subtotal + gst + serviceCharge;

  if (cart.length === 0) {
    return (
      <div className={`max-w-md mx-auto min-h-[calc(100vh-4rem)] flex flex-col justify-between p-6 transition-colors duration-300 ${
        isDarkMode ? 'bg-[#0B0B0F] text-white' : 'bg-[#F7F9FC] text-gray-950'
      }`}>
        <div className="flex-1 flex flex-col items-center justify-center py-12">
          {/* Wave Brand Emblem */}
          <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 border ${
            isDarkMode 
              ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' 
              : 'bg-amber-50 border-amber-200/50 text-amber-500'
          }`}>
            <Waves className="h-7 w-7 text-amber-500 animate-pulse" />
          </div>
          <h3 className={`font-serif font-black text-xl mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            Your Cart is Empty
          </h3>
          <p className="text-sm text-gray-400 text-center max-w-xs leading-relaxed mb-8">
            Add exquisite fine dining delicacies from our menu to begin your culinary journey.
          </p>
          <button
            onClick={onBackToMenu}
            className="bg-amber-500 hover:bg-amber-600 text-white font-sans font-bold text-sm px-8 py-3 rounded-full shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer"
          >
            Explore Exquisite Menu
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`max-w-md mx-auto min-h-[calc(100vh-4rem)] flex flex-col justify-between transition-colors duration-300 ${
      isDarkMode ? 'bg-[#0B0B0F]' : 'bg-[#F7F9FC]'
    }`}>
      {/* Back to Menu */}
      <div className={`px-4 py-3 flex items-center border-b shadow-sm ${
        isDarkMode ? 'bg-[#0E1A2B] border-blue-950 text-white' : 'bg-white border-gray-100 text-gray-900'
      }`}>
        <button
          onClick={onBackToMenu}
          className={`p-1.5 rounded-full transition-colors cursor-pointer mr-3 ${
            isDarkMode ? 'hover:bg-blue-900/30 text-white' : 'hover:bg-gray-50 text-gray-800'
          }`}
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div>
          <h2 className="font-serif font-bold text-lg">Review Table Order</h2>
          <span className="text-[10px] text-amber-500 font-sans uppercase tracking-widest font-bold">
            7 Waves Resto & Cafe
          </span>
        </div>
      </div>

      {/* Cart Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-28">
        
        {/* Table Locked Banner */}
        <div className={`p-4 rounded-2xl shadow-sm flex items-center justify-between border ${
          isDarkMode 
            ? 'bg-gradient-to-r from-blue-950 to-[#0E1A2B] border-blue-900/30 text-white' 
            : 'bg-gradient-to-r from-gray-950 to-gray-800 border-gray-800 text-white'
        }`}>
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
              isDarkMode ? 'bg-amber-500/15 border-amber-500/20' : 'bg-white/10 border-white/15'
            }`}>
              <span className="font-serif font-black text-amber-400 text-lg">
                {tableId || '12'}
              </span>
            </div>
            <div>
              <p className="font-sans font-bold text-sm">Table Confirmed</p>
              <p className="text-[10px] text-gray-400">Locked to Table ID {tableId || '12'}</p>
            </div>
          </div>
          <span className="text-[10px] bg-amber-500/20 text-amber-400 font-bold border border-amber-500/30 px-2.5 py-1 rounded-full uppercase tracking-wider font-sans">
            Locked
          </span>
        </div>

        {/* Selected Items List */}
        <div className={`rounded-2xl p-4 shadow-sm border ${
          isDarkMode 
            ? 'bg-[#0E1A2B] border-blue-950 text-white' 
            : 'bg-white border-gray-100/50 text-gray-900'
        }`}>
          <h3 className={`text-xs font-sans tracking-wider uppercase font-bold border-b pb-2 ${
            isDarkMode ? 'text-amber-400/80 border-blue-950' : 'text-gray-400 border-gray-50'
          }`}>
            Selected Delicacies
          </h3>

          <div className={`divide-y ${isDarkMode ? 'divide-blue-950' : 'divide-gray-50'}`}>
            {cart.map((item, index) => (
              <div key={`${item.menuItem.id}-${index}`} className="py-3.5 flex flex-col first:pt-3 last:pb-0">
                <div className="flex items-center space-x-3">
                  {/* Thumb */}
                  <img
                    src={item.menuItem.image}
                    alt={item.menuItem.name}
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 object-cover rounded-xl shrink-0"
                  />

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h4 className={`font-sans font-bold text-sm truncate ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      {item.menuItem.name}
                    </h4>
                    <div className="flex items-center space-x-2 mt-0.5">
                      <span className="text-xs text-amber-500 font-bold">
                        ₹{item.menuItem.price}
                      </span>
                      {item.spiceLevel && (
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold border ${
                          isDarkMode 
                            ? 'bg-amber-500/10 border-amber-500/25 text-amber-400' 
                            : 'bg-amber-50 border-amber-100 text-amber-700'
                        }`}>
                          {item.spiceLevel}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Controls */}
                  <div className="flex items-center space-x-2 shrink-0">
                    <div className={`flex items-center rounded-lg px-1 py-0.5 space-x-2 border ${
                      isDarkMode ? 'bg-[#0B0B0F] border-blue-900/30' : 'bg-gray-50 border-gray-100'
                    }`}>
                      <button
                        onClick={() => onDecrement(index)}
                        className={`w-6 h-6 rounded-md flex items-center justify-center active:scale-95 transition-all cursor-pointer border ${
                          isDarkMode 
                            ? 'bg-[#15253F] border-blue-900/20 text-gray-300' 
                            : 'bg-white border-gray-200/40 text-gray-600'
                        }`}
                      >
                        <Minus className="h-2.5 w-2.5" />
                      </button>
                      <span className={`font-sans font-bold text-xs w-3 text-center ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onIncrement(index)}
                        className={`w-6 h-6 rounded-md flex items-center justify-center active:scale-95 transition-all cursor-pointer border ${
                          isDarkMode 
                            ? 'bg-[#15253F] border-blue-900/20 text-gray-300' 
                            : 'bg-white border-gray-200/40 text-gray-600'
                        }`}
                      >
                        <Plus className="h-2.5 w-2.5" />
                      </button>
                    </div>

                    <button
                      onClick={() => onRemoveItem(index)}
                      className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                        isDarkMode ? 'text-gray-400 hover:text-red-400 hover:bg-red-900/10' : 'text-gray-400 hover:text-red-500 hover:bg-red-50'
                      }`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Customizable Instructions Option */}
                <div className="ml-17 mt-1.5 flex flex-col items-start">
                  {editingIndex !== index ? (
                    <div className="flex flex-col items-start w-full">
                      {item.customNotes ? (
                        <div className="w-full">
                          <div className={`p-2 rounded-xl flex items-start space-x-2 text-[11px] border ${
                            isDarkMode 
                              ? 'bg-[#0B0B0F]/60 border-blue-950/40 text-gray-400' 
                              : 'bg-amber-50/40 border-amber-100/30 text-amber-800/85'
                          }`}>
                            <MessageSquare className="h-3 w-3 mt-0.5 shrink-0 text-amber-500" />
                            <span className="italic flex-1">“{item.customNotes}”</span>
                          </div>
                          <button
                            onClick={() => {
                              setEditingIndex(index);
                              setTempNotes(item.customNotes || '');
                            }}
                            className="text-[10px] font-sans font-extrabold text-amber-500 hover:text-amber-600 transition-colors mt-1 underline cursor-pointer"
                          >
                            Edit Cooking Instruction
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            setEditingIndex(index);
                            setTempNotes('');
                          }}
                          className={`text-[10px] font-sans font-bold flex items-center space-x-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                            isDarkMode
                              ? 'bg-blue-950/20 border-blue-900/30 text-gray-400 hover:text-white'
                              : 'bg-gray-50 border-gray-150 text-gray-600 hover:bg-gray-100'
                          }`}
                        >
                          <MessageSquare className="h-3 w-3 text-amber-500" />
                          <span>Add Chef Instruction</span>
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="w-full mt-2 p-3 rounded-2xl border bg-slate-50/50 dark:bg-[#0B0B0F]/80 dark:border-blue-900/20">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-amber-500 mb-1.5">
                        Instructions for Chef:
                      </label>
                      <textarea
                        value={tempNotes}
                        onChange={(e) => setTempNotes(e.target.value)}
                        placeholder="E.g. No onion, extra spicy, gluten-free, allergy alert..."
                        rows={2}
                        className={`w-full text-xs p-2.5 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                          isDarkMode 
                            ? 'bg-[#0E1A2B] border-blue-950 text-white placeholder-gray-500' 
                            : 'bg-white border-gray-200 text-gray-800 placeholder-gray-400'
                        }`}
                      />
                      <div className="flex justify-end space-x-2 mt-2">
                        <button
                          onClick={() => setEditingIndex(null)}
                          className="px-2.5 py-1 rounded-lg text-[9px] font-sans font-bold uppercase tracking-wider text-gray-400 hover:text-gray-300 cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => {
                            if (onUpdateCustomNotes) {
                              onUpdateCustomNotes(index, tempNotes);
                            }
                            setEditingIndex(null);
                          }}
                          className="px-3.5 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-[9px] font-sans font-bold uppercase tracking-wider shadow-sm transition-colors cursor-pointer"
                        >
                          Apply Note
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* General Order Instructions Card */}
        <div className={`rounded-2xl p-4 shadow-sm border ${
          isDarkMode 
            ? 'bg-[#0E1A2B] border-blue-950 text-white' 
            : 'bg-white border-gray-100/50 text-gray-900'
        }`}>
          <div className="flex items-center space-x-2 border-b pb-2 mb-3">
            <MessageSquare className="h-4 w-4 text-amber-500" />
            <h3 className={`text-xs font-sans tracking-wider uppercase font-bold ${
              isDarkMode ? 'text-amber-400/80' : 'text-gray-400'
            }`}>
              General Table Instructions
            </h3>
          </div>

          <textarea
            value={generalInstructions}
            onChange={(e) => handleSaveGeneralInstructions(e.target.value)}
            placeholder="E.g. Send appetizer first, bring extra napkins, keep water filled..."
            rows={2}
            className={`w-full text-xs p-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all ${
              isDarkMode 
                ? 'bg-[#0B0B0F] border-blue-900/30 text-white placeholder-gray-500 focus:border-amber-500' 
                : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400 focus:border-amber-500'
            }`}
          />
          <span className="text-[10px] text-gray-400 block mt-1.5 leading-tight">
            These notes apply to your overall table order and are transmitted directly to the servers.
          </span>
        </div>

        {/* Pricing Summary */}
        <div className={`rounded-2xl p-4 shadow-sm border ${
          isDarkMode 
            ? 'bg-[#0E1A2B] border-blue-950 text-white' 
            : 'bg-white border-gray-100/50 text-gray-900'
        }`}>
          <h3 className={`text-xs font-sans tracking-wider uppercase font-bold border-b pb-2 ${
            isDarkMode ? 'text-amber-400/80 border-blue-950' : 'text-gray-400 border-gray-50'
          }`}>
            Payment Summary
          </h3>

          <div className="flex justify-between text-sm py-1">
            <span className="text-gray-400 font-medium">Subtotal</span>
            <span className="font-bold">₹{subtotal}</span>
          </div>

          <div className="flex justify-between text-sm py-1">
            <span className="text-gray-400 font-medium">GST (5%)</span>
            <span className="font-bold">₹{gst}</span>
          </div>

          <div className="flex justify-between text-sm py-1">
            <span className="text-gray-400 font-medium">Service Charge (5%)</span>
            <span className="font-bold">₹{serviceCharge}</span>
          </div>

          <div className={`border-t border-dashed my-2 pt-2.5 flex justify-between ${
            isDarkMode ? 'border-blue-950' : 'border-gray-100'
          }`}>
            <span className="font-serif font-black text-base">Grand Total</span>
            <span className="font-serif font-black text-lg text-amber-500">₹{total}</span>
          </div>
        </div>

        {/* Security disclaimer */}
        <div className="flex items-center justify-center space-x-1.5 text-gray-400 py-1">
          <ShieldCheck className="h-4 w-4 text-emerald-500" />
          <span className="text-[10px] font-sans tracking-wide">
            Verified Table Order • Encrypted Local Session
          </span>
        </div>
      </div>

      {/* CTA Sticky Footbar */}
      <div className={`fixed bottom-0 left-0 right-0 z-40 border-t px-6 py-4 max-w-md mx-auto shadow-[0_-8px_35px_rgb(0,0,0,0.05)] ${
        isDarkMode ? 'bg-[#0E1A2B]/95 border-blue-950' : 'bg-white/95 border-gray-100'
      }`}>
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={onPlaceOrder}
          className="relative w-full overflow-hidden bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-white font-sans font-black text-sm py-3.5 px-6 rounded-full shadow-[0_4px_20px_rgba(245,197,66,0.3)] hover:shadow-[0_4px_25px_rgba(245,197,66,0.45)] transition-all duration-200 cursor-pointer flex items-center justify-center space-x-2"
        >
          <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,0.15)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.15)_50%,rgba(255,255,255,0.15)_75%,transparent_75%,transparent)] bg-[length:1rem_1rem] animate-[shimmer_1s_infinite_linear] opacity-15" />
          <span>Place Secure Table Order • ₹{total}</span>
        </motion.button>
      </div>
    </div>
  );
}

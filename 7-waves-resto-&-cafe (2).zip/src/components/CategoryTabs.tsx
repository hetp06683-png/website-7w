import React from 'react';
import { motion } from 'framer-motion';

interface CategoryTabsProps {
  selectedCategory: string;
  onSelectCategory: (category: any) => void;
  isDarkMode?: boolean;
}

const CATEGORIES = [
  { id: 'starters', label: 'Starters' },
  { id: 'mains', label: 'Main Course' },
  { id: 'seafood', label: 'Seafood' },
  { id: 'drinks', label: 'Drinks' },
  { id: 'desserts', label: 'Desserts' }
];

export default function CategoryTabs({
  selectedCategory,
  onSelectCategory,
  isDarkMode = false
}: CategoryTabsProps) {
  return (
    <div className={`w-full py-3 sticky top-16 z-30 border-b transition-colors duration-300 overflow-hidden ${
      isDarkMode 
        ? 'bg-[#0E1A2B] border-blue-950 shadow-blue-950/10' 
        : 'bg-white border-gray-100/80 shadow-sm'
    }`}>
      <div className="max-w-md mx-auto px-4">
        <div className="flex space-x-2.5 overflow-x-auto scrollbar-none pb-1 -mb-1">
          {CATEGORIES.map((category) => {
            const isActive = selectedCategory === category.id;
            return (
              <button
                key={category.id}
                onClick={() => onSelectCategory(category.id)}
                className="relative px-4 py-2 rounded-full text-xs font-sans font-medium tracking-wide transition-colors duration-200 whitespace-nowrap focus:outline-none cursor-pointer"
              >
                {/* Active background slider */}
                {isActive && (
                  <motion.div
                    layoutId="activeCategory"
                    className="absolute inset-0 bg-amber-500 rounded-full shadow-sm"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                <span
                  className={`relative z-10 font-medium ${
                    isActive 
                      ? 'text-white font-semibold' 
                      : isDarkMode
                        ? 'text-gray-400 hover:text-white'
                        : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  {category.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

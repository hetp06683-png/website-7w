import React from 'react';

interface BrandLogoProps {
  className?: string;
  showText?: boolean;
  isDarkMode?: boolean;
}

export default function BrandLogo({ className = 'h-16', showText = true, isDarkMode = true }: BrandLogoProps) {
  // We'll render a beautiful high-fidelity SVG that perfectly replicates the official logo from the screenshot:
  // - Premium flow of two rich cyan/blue waves on top
  // - "THE" on top left
  // - "7 WAVES" in elegant serif golden-yellow font
  // - "RESTO & CAFE" with a double cyan bar extension to the right
  
  const textColor = isDarkMode ? '#FFFFFF' : '#0F172A';
  const goldColor = '#F5C542'; // Exquisite branding gold
  const cyanColor = '#00B4D8'; // Vibrant wave cyan
  const lightBlueColor = '#4EA8DE'; // Sky wave blue
  
  return (
    <div className={`flex items-center select-none ${className}`}>
      <svg
        viewBox="0 0 280 95"
        className="h-full w-auto"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Waves Gradient */}
          <linearGradient id="waveGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="50%" stopColor="#00B4D8" />
            <stop offset="100%" stopColor="#0077B6" />
          </linearGradient>

          {/* Golden Lettering Gradient */}
          <linearGradient id="brandGold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF2A3" />
            <stop offset="40%" stopColor="#F5C542" />
            <stop offset="100%" stopColor="#D4A017" />
          </linearGradient>
          
          <linearGradient id="brandGoldLight" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF" />
            <stop offset="100%" stopColor="#F5C542" />
          </linearGradient>
        </defs>

        {/* --- DYNAMIC WAVES (CYAN & BLUE) --- */}
        {/* Upper Wave */}
        <path
          d="M 15,22 C 45,5 85,2 125,18 C 165,34 205,32 235,16"
          fill="none"
          stroke="url(#waveGrad)"
          strokeWidth="4.8"
          strokeLinecap="round"
        />
        {/* Middle/Lower Wave */}
        <path
          d="M 22,31 C 55,14 90,11 130,27 C 170,43 200,41 230,25"
          fill="none"
          stroke="url(#waveGrad)"
          strokeWidth="3.8"
          strokeLinecap="round"
          opacity="0.85"
        />

        {/* --- LOGO TEXT --- */}
        {showText && (
          <>
            {/* "THE" label */}
            <text
              x="22"
              y="45"
              fontFamily="system-ui, -apple-system, sans-serif"
              fontWeight="900"
              fontSize="7.5"
              fill={goldColor}
              letterSpacing="0.2em"
            >
              THE
            </text>

            {/* "7 WAVES" serif text */}
            <text
              x="20"
              y="71"
              fontFamily="Georgia, 'Times New Roman', serif"
              fontWeight="900"
              fontSize="29"
              fill="url(#brandGold)"
              letterSpacing="0.04em"
              style={{ textShadow: '0 1px 3px rgba(0,0,0,0.15)' }}
            >
              7 WAVES
            </text>

            {/* TM symbol */}
            <text
              x="233"
              y="53"
              fontFamily="system-ui, -apple-system, sans-serif"
              fontWeight="bold"
              fontSize="6"
              fill={goldColor}
            >
              TM
            </text>

            {/* "RESTO & CAFE" */}
            <text
              x="22"
              y="85"
              fontFamily="system-ui, -apple-system, sans-serif"
              fontWeight="800"
              fontSize="8.5"
              fill={goldColor}
              letterSpacing="0.18em"
            >
              RESTO & CAFE
            </text>

            {/* Double Cyan/Blue horizontal line stretching to the right */}
            {/* Top Cyan line */}
            <line
              x1="165"
              y1="80.5"
              x2="235"
              y2="80.5"
              stroke="#00B4D8"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            {/* Bottom Cyan line */}
            <line
              x1="165"
              y1="85.5"
              x2="235"
              y2="85.5"
              stroke="#00B4D8"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </>
        )}
      </svg>
    </div>
  );
}

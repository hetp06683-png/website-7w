import React, { useState, useEffect } from 'react';
import { CheckCircle2, CookingPot, Flame, Utensils, Clock, Sparkles, RefreshCw, AlertCircle, Waves } from 'lucide-react';
import { motion } from 'framer-motion';
import { Order } from '../types';

interface OrderTrackingProps {
  order: Order | null;
  onBackToMenu: () => void;
  onAdvanceStatus?: () => void; // Optional manually advance simulation
  isDarkMode?: boolean;
}

const STAGES = [
  {
    key: 'received',
    title: 'Order Received',
    desc: 'Sent to the primary kitchen terminal',
    icon: CheckCircle2
  },
  {
    key: 'preparing',
    title: 'Preparing Delicacies',
    desc: 'Our head chef is crafting your plates',
    icon: CookingPot
  },
  {
    key: 'almost_ready',
    title: 'Plating & Garnishing',
    desc: 'Fine-tuning visual styling and flavors',
    icon: Flame
  },
  {
    key: 'served',
    title: 'Served at Table',
    desc: 'Enjoy your exquisite culinary experience',
    icon: Utensils
  }
];

export default function OrderTracking({
  order,
  onBackToMenu,
  onAdvanceStatus,
  isDarkMode = false
}: OrderTrackingProps) {
  const [timeLeft, setTimeLeft] = useState(15 * 60); // 15 mins in seconds

  useEffect(() => {
    if (!order) return;
    
    // Set simulated countdown based on status
    if (order.status === 'received') setTimeLeft(15 * 60);
    else if (order.status === 'preparing') setTimeLeft(10 * 60);
    else if (order.status === 'almost_ready') setTimeLeft(3 * 60);
    else setTimeLeft(0);

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [order?.status, order?.id]);

  if (!order) {
    return (
      <div className={`max-w-md mx-auto min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center p-6 transition-colors duration-300 ${
        isDarkMode ? 'bg-[#0B0B0F] text-white' : 'bg-[#F7F9FC] text-gray-950'
      }`}>
        <AlertCircle className="h-10 w-10 text-amber-500 mb-3 animate-bounce" />
        <h3 className="font-serif font-bold text-lg mb-1">No Active Orders</h3>
        <p className="text-xs text-gray-500 text-center mb-6">You haven't placed an order for this session yet.</p>
        <button
          onClick={onBackToMenu}
          className="bg-amber-500 text-white font-sans font-bold text-xs px-6 py-2.5 rounded-full shadow cursor-pointer"
        >
          Browse Menu
        </button>
      </div>
    );
  }

  // Determine stage indexes
  const getStatusIndex = (status: string) => {
    switch (status) {
      case 'received': return 0;
      case 'preparing': return 1;
      case 'almost_ready': return 2;
      case 'served': return 3;
      default: return 0;
    }
  };

  const currentIdx = getStatusIndex(order.status);

  // Format time MM:SS
  const formatTime = (seconds: number) => {
    if (seconds === 0) return 'Arrived! 🎉';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className={`max-w-md mx-auto min-h-[calc(100vh-4rem)] flex flex-col justify-between transition-colors duration-300 ${
      isDarkMode ? 'bg-[#0B0B0F]' : 'bg-[#F7F9FC]'
    }`}>
      {/* Header */}
      <div className={`px-5 py-4 flex items-center justify-between border-b shadow-sm ${
        isDarkMode ? 'bg-[#0E1A2B] border-blue-950 text-white' : 'bg-white border-gray-100 text-gray-900'
      }`}>
        <div>
          <h2 className="font-serif font-bold text-lg">Track Live Order</h2>
          <span className="text-[10px] text-amber-500 font-sans uppercase tracking-wider font-bold">
            Table {order.tableId} • Order #{order.id}
          </span>
        </div>
        <div className={`border px-2.5 py-1 rounded-full flex items-center space-x-1 ${
          isDarkMode ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-emerald-50 border-emerald-200/50 text-emerald-800'
        }`}>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] font-bold">
            Kitchen Live
          </span>
        </div>
      </div>

      {/* Main Tracker Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
        
        {/* Animated Wave visual effect for premium experience */}
        <div className={`relative overflow-hidden rounded-2xl p-5 border shadow-md flex items-center justify-between ${
          isDarkMode 
            ? 'bg-gradient-to-br from-[#0E1A2B] to-blue-950 border-blue-900/30 text-white' 
            : 'bg-white border-gray-100 text-gray-900'
        }`}>
          {/* Wave animated decorations */}
          <div className="absolute inset-0 pointer-events-none opacity-5">
            <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
              <path d="M0,50 C30,40 70,60 100,50 L100,100 L0,100 Z" fill="currentColor" className="animate-pulse" />
            </svg>
          </div>

          <div className="flex items-center space-x-4 relative z-10">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${
              isDarkMode ? 'bg-amber-500/10 border-amber-500/25' : 'bg-amber-50 border-amber-100'
            }`}>
              <Clock className="h-6 w-6 text-amber-500 animate-pulse" />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-gray-400 font-extrabold font-sans">
                Estimated Arrival
              </p>
              <h3 className="font-serif font-black text-2xl mt-0.5">
                {formatTime(timeLeft)}
              </h3>
            </div>
          </div>

          <div className="text-right relative z-10">
            <span className="text-[10px] bg-amber-500/20 text-amber-400 font-black px-2.5 py-1 rounded-lg uppercase tracking-wider font-sans border border-amber-500/35">
              {order.status === 'served' ? 'Ready' : 'In Progress'}
            </span>
          </div>
        </div>

        {/* Live Step Progress Timeline */}
        <div className={`rounded-2xl p-5 shadow-sm border ${
          isDarkMode ? 'bg-[#0E1A2B] border-blue-950 text-white' : 'bg-white border-gray-100/50 text-gray-950'
        }`}>
          <h3 className={`text-xs font-sans tracking-wider uppercase font-bold border-b pb-3 mb-5 ${
            isDarkMode ? 'text-amber-400/85 border-blue-950' : 'text-gray-400 border-gray-50'
          }`}>
            Preparation Journey
          </h3>

          <div className="relative pl-10 space-y-6">
            {/* Vertical Progress Line */}
            <div className={`absolute left-4.5 top-2.5 bottom-2.5 w-0.5 ${isDarkMode ? 'bg-blue-950' : 'bg-gray-100'}`}>
              <div 
                className="w-full bg-amber-500 transition-all duration-1000 ease-in-out"
                style={{ height: `${(currentIdx / (STAGES.length - 1)) * 100}%` }}
              />
            </div>

            {STAGES.map((stage, idx) => {
              const Icon = stage.icon;
              const isPast = idx < currentIdx;
              const isCurrent = idx === currentIdx;
              const isFuture = idx > currentIdx;

              return (
                <div key={stage.key} className="relative flex items-start space-x-4">
                  {/* Circle Indicator */}
                  <div className="absolute -left-10 top-0.5 flex items-center justify-center z-10">
                    {isPast ? (
                      <motion.div
                        initial={{ scale: 0.8 }}
                        animate={{ scale: 1 }}
                        className="w-9 h-9 rounded-full bg-amber-500 border-2 border-white shadow-sm text-white flex items-center justify-center"
                      >
                        <CheckCircle2 className="h-5 w-5 fill-amber-500 stroke-white" />
                      </motion.div>
                    ) : isCurrent ? (
                      <motion.div
                        animate={{ scale: [1, 1.1, 1] }}
                        transition={{ repeat: Infinity, duration: 2 }}
                        className={`w-9 h-9 rounded-full border-2 shadow-sm flex items-center justify-center text-amber-500 ${
                          isDarkMode ? 'bg-[#0E1A2B] border-amber-500' : 'bg-white border-amber-500'
                        }`}
                      >
                        <Icon className="h-4 w-4 animate-pulse" />
                      </motion.div>
                    ) : (
                      <div className={`w-9 h-9 rounded-full border-2 shadow-sm flex items-center justify-center text-gray-400 ${
                        isDarkMode ? 'bg-[#0E1A2B] border-blue-900/30' : 'bg-white border-gray-100'
                      }`}>
                        <Icon className="h-4 w-4" />
                      </div>
                    )}
                  </div>

                  {/* Stage description details */}
                  <div className="flex-1">
                    <h4 className={`font-sans font-bold text-sm transition-colors duration-300 ${
                      isCurrent 
                        ? isDarkMode ? 'text-white font-black' : 'text-gray-950 font-black' 
                        : isPast 
                          ? 'text-gray-400' 
                          : 'text-gray-400/50'
                    }`}>
                      {stage.title}
                    </h4>
                    <p className={`text-xs mt-0.5 transition-colors duration-300 ${
                      isCurrent 
                        ? 'text-gray-400' 
                        : isPast 
                          ? 'text-gray-500/80' 
                          : 'text-gray-500/30'
                    }`}>
                      {stage.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Ordered Items summary details */}
        <div className={`rounded-2xl p-5 shadow-sm border ${
          isDarkMode ? 'bg-[#0E1A2B] border-blue-950 text-white' : 'bg-white border-gray-100/50 text-gray-950'
        }`}>
          <h3 className={`text-xs font-sans tracking-wider uppercase font-bold border-b pb-2.5 mb-3.5 ${
            isDarkMode ? 'text-amber-400/80 border-blue-950' : 'text-gray-400 border-gray-50'
          }`}>
            Your Delicacies Summary
          </h3>

          <div className="space-y-3">
            {order.items.map((item, index) => (
              <div key={index} className="flex justify-between items-center text-xs">
                <div className="flex items-center space-x-2">
                  <span className={`font-mono px-2 py-1 rounded border ${
                    isDarkMode ? 'bg-[#0B0B0F] border-blue-900/30 text-amber-400' : 'bg-gray-50 border-gray-200/30 text-gray-500'
                  }`}>
                    {item.quantity}x
                  </span>
                  <div>
                    <span className="font-sans font-semibold">
                      {item.menuItem.name}
                    </span>
                    {item.spiceLevel && (
                      <span className="block text-[9px] text-amber-500 font-bold">
                        • {item.spiceLevel}
                      </span>
                    )}
                    {item.customNotes && (
                      <span className="block text-[9px] text-gray-400 italic">
                        “{item.customNotes}”
                      </span>
                    )}
                  </div>
                </div>
                <span className="font-bold">
                  ₹{item.menuItem.price * item.quantity}
                </span>
              </div>
            ))}

            <div className={`border-t pt-3 flex justify-between text-xs font-sans ${
              isDarkMode ? 'border-blue-950' : 'border-gray-50'
            }`}>
              <span className="text-gray-400">Total Charged (Incl. GST)</span>
              <span className="font-black text-amber-500">
                ₹{order.total}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Back to Menu Fixed Footer */}
      <div className={`fixed bottom-0 left-0 right-0 z-40 border-t px-6 py-4 max-w-md mx-auto shadow-[0_-8px_35px_rgb(0,0,0,0.05)] ${
        isDarkMode ? 'bg-[#0E1A2B]/95 border-blue-950' : 'bg-white/95 border-gray-100'
      }`}>
        <button
          onClick={onBackToMenu}
          className="w-full bg-amber-500 hover:bg-amber-600 text-white font-sans font-bold text-sm py-3 px-6 rounded-full shadow-md transition-colors cursor-pointer text-center block"
        >
          Add More to Order
        </button>
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { QrCode, MonitorPlay, Sparkles, Waves, Check, ExternalLink, Printer, Download, Globe, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import BrandLogo from './BrandLogo';

interface QRGeneratorProps {
  onSimulateTableScan: (tableId: string) => void;
  activeTableId: string | null;
  onClose: () => void;
  isDarkMode?: boolean;
  customBaseUrl?: string;
  onUpdateCustomBaseUrl?: (url: string) => void;
}

export default function QRGenerator({
  onSimulateTableScan,
  activeTableId,
  onClose,
  isDarkMode = false,
  customBaseUrl = '',
  onUpdateCustomBaseUrl
}: QRGeneratorProps) {
  // 25 tables as requested
  const tables = Array.from({ length: 25 }, (_, i) => i + 1);
  const [filterActive, setFilterActive] = useState<'all' | 'even' | 'odd'>('all');

  // Derive target URL for QR encoding using the custom base URL if configured, otherwise defaulting to window origin and path
  const getTableUrl = (tableNum: number) => {
    let base = customBaseUrl.trim();
    if (!base) {
      base = typeof window !== 'undefined' ? window.location.origin : 'https://the7waves.com';
    }
    if (base.endsWith('/')) {
      base = base.slice(0, -1);
    }
    return `${base}/table/${tableNum}`;
  };

  const filteredTables = tables.filter(num => {
    if (filterActive === 'even') return num % 2 === 0;
    if (filterActive === 'odd') return num % 2 !== 0;
    return true;
  });

  const handlePrintAll = () => {
    window.print();
  };

  return (
    <div className={`max-w-2xl mx-auto min-h-[calc(100vh-4rem)] flex flex-col justify-between transition-colors duration-300 print:bg-white print:text-black ${
      isDarkMode ? 'bg-[#0B0B0F]' : 'bg-[#F7F9FC]'
    }`}>
      {/* Header */}
      <div className={`px-5 py-4 flex items-center justify-between border-b shadow-sm print:hidden ${
        isDarkMode ? 'bg-[#0E1A2B] border-blue-950 text-white' : 'bg-white border-gray-100 text-gray-900'
      }`}>
        <div className="flex items-center space-x-2">
          <QrCode className="h-5 w-5 text-amber-500 animate-pulse" />
          <div>
            <h2 className="font-serif font-bold text-lg leading-tight">Fine Dining QR Placards</h2>
            <span className="text-[10px] text-amber-500 font-sans uppercase tracking-widest font-extrabold">
              Bespoke Digital Table Hub (Tables 1 - 25)
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-xs bg-amber-500 hover:bg-amber-600 text-white font-sans font-bold px-4 py-2 rounded-full shadow-sm transition-colors cursor-pointer"
        >
          Close Manager
        </button>
      </div>

      {/* Main Grid Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 pb-16">
        
        {/* Print & Filter Controls (Hidden in Print Mode) */}
        <div className={`rounded-2xl p-4 border shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3 print:hidden ${
          isDarkMode ? 'bg-[#0E1A2B] border-blue-950 text-white' : 'bg-white border-gray-100'
        }`}>
          <div className="flex items-center space-x-2.5">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Show:</span>
            <div className="flex space-x-1 bg-black/20 p-1 rounded-xl">
              {(['all', 'odd', 'even'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setFilterActive(mode)}
                  className={`text-[10px] uppercase font-sans font-black px-3 py-1 rounded-lg transition-all cursor-pointer ${
                    filterActive === mode
                      ? 'bg-amber-500 text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handlePrintAll}
            className="flex items-center space-x-1.5 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-sans font-bold text-xs rounded-full shadow-md transition-all cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Print All Placards (PDF)</span>
          </button>
        </div>

        {/* Info Explainer */}
        <div className={`rounded-2xl p-4 border shadow-sm space-y-2.5 print:hidden ${
          isDarkMode ? 'bg-[#0E1A2B] border-blue-950 text-white' : 'bg-white border-gray-100'
        }`}>
          <div className="flex items-center space-x-2 text-amber-500">
            <Sparkles className="h-4.5 w-4.5" />
            <h3 className="font-serif font-black text-sm">Fine Dining Self-Service Activation</h3>
          </div>
          <p className={`text-xs leading-relaxed ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
            Below are the high-resolution QR placards for tables 1 through 25. Standard smartphone cameras scanning these will immediately route guests to their designated table session.
          </p>
        </div>

        {/* Dynamic QR Configuration Card inside Admin Panel */}
        <div className={`p-4 rounded-2xl border text-left print:hidden ${
          isDarkMode ? 'bg-[#0E1A2B]/80 border-blue-900/30 text-white' : 'bg-white border-gray-200 text-gray-900 shadow-xs'
        }`}>
          <div className="flex items-center space-x-2 mb-2">
            <Globe className="h-4 w-4 text-amber-500" />
            <h4 className="font-sans font-bold text-xs uppercase tracking-wider">Configure Production Website / GitHub Pages URL</h4>
          </div>
          <p className="text-[10px] text-gray-400 leading-relaxed mb-3">
            Since the app is built locally, scanning with a physical phone requires a public URL. Enter your deployed link below (e.g. your <strong>GitHub Pages</strong> URL) to update all printed & simulated QR codes immediately.
          </p>
          
          <div className="flex flex-col gap-2">
            <div className="flex gap-2">
              <input
                type="text"
                value={customBaseUrl}
                onChange={(e) => {
                  if (onUpdateCustomBaseUrl) {
                    onUpdateCustomBaseUrl(e.target.value);
                  }
                }}
                placeholder={typeof window !== 'undefined' ? window.location.origin : 'https://the7waves.com'}
                className={`flex-1 px-3 py-2 text-xs rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono ${
                  isDarkMode 
                    ? 'bg-[#0B0B0F] border-blue-950 text-white placeholder-gray-600' 
                    : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                }`}
              />
              {customBaseUrl && (
                <button
                  onClick={() => {
                    if (onUpdateCustomBaseUrl) {
                      onUpdateCustomBaseUrl('');
                    }
                  }}
                  className="px-3 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 text-xs rounded-xl font-sans font-bold transition-all shrink-0 cursor-pointer"
                >
                  Reset
                </button>
              )}
            </div>
            
            <div className="flex flex-wrap items-center justify-between gap-2 mt-1">
              <span className="text-[9px] text-gray-500">
                Target QR Link: <code className="text-amber-500 font-mono font-bold">{getTableUrl(1).split('?')[0]}</code>
              </span>
              
              <button
                onClick={() => {
                  if (onUpdateCustomBaseUrl && typeof window !== 'undefined') {
                    onUpdateCustomBaseUrl(window.location.origin);
                  }
                }}
                className="text-[10px] font-sans font-bold text-amber-500 hover:text-amber-400 flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="h-3 w-3" />
                <span>Set to Live Origin</span>
              </button>
            </div>
          </div>
        </div>

        {/* Tables Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 print:grid-cols-2">
          {filteredTables.map((tableNum) => {
            const tableIdStr = tableNum.toString();
            const isCurrentActive = activeTableId === tableIdStr;
            const isTable1 = tableNum === 1;
            const targetUrl = getTableUrl(tableNum);
            
            // Generate pristine high-quality QR code image matching the active container's live URL
            const qrCodeImgSrc = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(targetUrl)}&color=0F172A&bgcolor=FFFFFF&qzone=1`;

            return (
              <motion.div
                key={tableNum}
                whileHover={{ y: -3 }}
                className={`rounded-2xl p-5 shadow-md border transition-all duration-200 relative flex flex-col justify-between text-center bg-white border-amber-200 text-slate-900 print:break-inside-avoid print:border-slate-300 ${
                  isTable1
                    ? 'ring-4 ring-emerald-500/30 border-emerald-500/40'
                    : isCurrentActive
                      ? 'ring-4 ring-amber-500/30'
                      : ''
                }`}
              >
                {/* Visual Header of Card */}
                <div className="border-b border-gray-100 pb-3 mb-3 flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-[8px] uppercase tracking-[0.25em] font-sans font-black text-amber-500">The 7 Waves</span>
                    <h4 className="font-serif font-black text-base text-slate-900 leading-none mt-0.5">
                      Table {tableNum}
                    </h4>
                  </div>
                  {isTable1 ? (
                    <span className="bg-emerald-100 text-emerald-800 text-[9px] font-sans font-black uppercase px-2 py-0.5 rounded-full flex items-center space-x-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Open Table</span>
                    </span>
                  ) : isCurrentActive ? (
                    <span className="bg-emerald-100 text-emerald-800 text-[9px] font-sans font-black uppercase px-2 py-0.5 rounded-full flex items-center space-x-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span>Active</span>
                    </span>
                  ) : (
                    <span className="text-[8px] text-gray-400 font-sans tracking-wider uppercase">Session Card</span>
                  )}
                </div>

                {/* Exquisite QR Display */}
                <div className="p-3 bg-slate-50 border border-gray-100 rounded-2xl flex items-center justify-center aspect-square mx-auto w-40 relative group">
                  <img
                    src={qrCodeImgSrc}
                    alt={`QR Code Table ${tableNum}`}
                    className="w-full h-full object-contain rounded-lg"
                    loading="lazy"
                  />
                  {/* Hover scan overlay preview (Hidden in Print Mode) */}
                  <div className="absolute inset-0 bg-slate-900/90 opacity-0 group-hover:opacity-100 rounded-2xl transition-opacity duration-200 flex flex-col items-center justify-center p-2 text-white cursor-pointer print:hidden" onClick={() => onSimulateTableScan(tableIdStr)}>
                    <MonitorPlay className="h-6 w-6 text-[#F5C542] mb-1 animate-bounce" />
                    <span className="text-[10px] font-sans font-black uppercase tracking-wider text-center text-[#F5C542]">
                      Simulate Scan
                    </span>
                    <p className="text-[8px] text-gray-400 mt-0.5">Locks active Table ID</p>
                  </div>
                </div>

                {/* Card footer details / instructions */}
                <div className="mt-4 pt-3 border-t border-gray-50 flex flex-col items-center text-center">
                  <span className="text-[9px] text-slate-500 font-sans tracking-wide leading-tight">
                    {isTable1
                      ? 'Official Open QR sticker: anyone scanning this immediately unlocks Table 1'
                      : 'Scan to view premium digital menu & place direct table order'
                    }
                  </span>
                  
                  {/* Action Buttons */}
                  <div className="mt-3.5 space-y-1.5 w-full print:hidden">
                    <button
                      onClick={() => onSimulateTableScan(tableIdStr)}
                      className={`w-full py-2 px-3 rounded-xl text-[10px] font-sans font-extrabold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center space-x-1.5 ${
                        isCurrentActive
                          ? 'bg-emerald-500 text-white shadow-sm'
                          : 'bg-amber-500 hover:bg-amber-600 text-white shadow-sm'
                      }`}
                    >
                      {isCurrentActive ? (
                        <>
                          <Check className="h-3 w-3" />
                          <span>Connected Session</span>
                        </>
                      ) : (
                        <>
                          <MonitorPlay className="h-3 w-3" />
                          <span>Simulate Table {tableNum} Scan</span>
                        </>
                      )}
                    </button>
                    <a
                      href={targetUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="w-full py-1 text-[9px] font-sans font-bold text-gray-400 hover:text-amber-500 transition-all flex items-center justify-center space-x-1"
                    >
                      <span>Direct Test Link</span>
                      <ExternalLink className="h-2.5 w-2.5" />
                    </a>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { ShoppingCart, QrCode, Sun, Moon } from 'lucide-react';
import { motion } from 'framer-motion';
import BrandLogo from './BrandLogo';

interface HeaderProps {
  tableId: string | null;
  cartCount: number;
  onOpenCart: () => void;
  onOpenAdmin: () => void;
  currentView: string;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function Header({
  tableId,
  cartCount,
  onOpenCart,
  onOpenAdmin,
  currentView,
  isDarkMode,
  onToggleDarkMode
}: HeaderProps) {
  return (
    <header className={`sticky top-0 z-40 w-full backdrop-blur-md border-b transition-all duration-300 ${
      isDarkMode 
        ? 'bg-[#0E1A2B]/90 border-blue-900/30 text-white' 
        : 'bg-white/85 border-gray-100 text-gray-900'
    }`}>
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
        
        {/* Brand Logo and Title */}
        <div className="flex items-center cursor-pointer" onClick={() => window.location.reload()}>
          <BrandLogo className="h-10" showText={true} isDarkMode={isDarkMode} />
        </div>

        {/* Action Buttons & Badges */}
        <div className="flex items-center space-x-2">
          
          {/* Table ID Badge */}
          {tableId && (
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className={`px-2.5 py-1 rounded-full flex items-center space-x-1 ${
                isDarkMode 
                  ? 'bg-amber-500/10 border border-amber-500/25 text-amber-400' 
                  : 'bg-amber-50 border border-amber-200/60 text-amber-800'
              }`}
            >
              <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
              <span className="text-[10px] font-sans font-bold uppercase tracking-wider">
                T-{tableId}
              </span>
            </motion.div>
          )}

          {/* Theme Toggle Button */}
          <button
            onClick={onToggleDarkMode}
            className={`p-2 rounded-full transition-all duration-200 cursor-pointer border ${
              isDarkMode 
                ? 'bg-[#0B0B0F] border-blue-950 text-amber-400 hover:bg-[#15253F]' 
                : 'bg-gray-50 border-gray-150 text-gray-600 hover:bg-gray-100'
            }`}
            title={isDarkMode ? 'Switch to Light Luxury' : 'Switch to Dark Luxury'}
          >
            {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>

          {/* Admin Panel (QR Hub) Button */}
          <button
            onClick={onOpenAdmin}
            className={`p-2 rounded-full transition-all duration-200 cursor-pointer border ${
              currentView === 'admin'
                ? 'bg-amber-500 border-amber-600 text-white shadow-md'
                : isDarkMode 
                  ? 'bg-[#0B0B0F] border-blue-950 text-gray-300 hover:bg-[#15253F]' 
                  : 'bg-gray-50 border-gray-150 text-gray-600 hover:bg-gray-100'
            }`}
            title="Table QR Hub"
          >
            <QrCode className="h-4 w-4" />
          </button>

          {/* Cart Icon Button */}
          <button
            onClick={onOpenCart}
            className={`relative p-2.5 rounded-full shadow-md transition-all duration-200 cursor-pointer ${
              isDarkMode 
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-500/10' 
                : 'bg-gray-900 hover:bg-amber-500 text-white'
            }`}
          >
            <ShoppingCart className="h-4 w-4" />
            {cartCount > 0 && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                key={cartCount}
                className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-sm"
              >
                {cartCount}
              </motion.span>
            )}
          </button>

        </div>
      </div>
    </header>
  );
}

import React from 'react';
import { Check, Waves, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

interface QREntryScreenProps {
  tableId: string;
  onStartOrdering: () => void;
  isDarkMode?: boolean;
}

export default function QREntryScreen({
  tableId,
  onStartOrdering,
  isDarkMode = false
}: QREntryScreenProps) {
  return (
    <div className={`relative w-full max-w-md mx-auto min-h-screen flex flex-col justify-between p-6 overflow-hidden transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-[#0B0B0F] text-white' 
        : 'bg-gradient-to-b from-white via-slate-50 to-[#F1F5F9] text-gray-950'
    }`}>
      
      {/* Wave Background Blobs */}
      <div className={`absolute top-[-10%] left-[-20%] w-[140%] h-[50%] rounded-full blur-3xl pointer-events-none ${
        isDarkMode 
          ? 'bg-[radial-gradient(ellipse_at_top,rgba(245,197,66,0.12),transparent_60%)]' 
          : 'bg-[radial-gradient(ellipse_at_top,rgba(245,197,66,0.06),transparent_60%)]'
      }`} />
      <div className={`absolute bottom-[-15%] right-[-10%] w-[120%] h-[40%] rounded-full blur-2xl pointer-events-none ${
        isDarkMode 
          ? 'bg-[radial-gradient(ellipse_at_bottom,rgba(245,197,66,0.08),transparent_50%)]' 
          : 'bg-[radial-gradient(ellipse_at_bottom,rgba(245,197,66,0.04),transparent_50%)]'
      }`} />

      {/* Decorative Wave Waveforms */}
      <div className="absolute inset-x-0 top-1/3 opacity-[0.04] pointer-events-none select-none">
        <svg viewBox="0 0 1440 320" className="w-full h-auto">
          <path fill="#F5C542" d="M0,160L48,176C96,192,192,224,288,224C384,224,480,192,576,165.3C672,139,768,117,864,128C960,139,1056,181,1152,192C1248,203,1344,181,1392,170.7L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
      </div>

      {/* Header Info */}
      <div className="pt-12 text-center z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center space-x-1.5 bg-amber-500/10 text-amber-500 px-3.5 py-1 rounded-full text-xs font-sans font-bold uppercase tracking-wider mb-4 border border-amber-500/15"
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span>Exclusive Table Service</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.15 }}
          className={`font-serif font-black text-4xl tracking-tight leading-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
        >
          7 Waves
        </motion.h1>
        <p className="text-amber-500 tracking-widest font-sans font-extrabold text-xs uppercase mt-1">
          Resto & Cafe
        </p>
      </div>

      {/* Central Confirmation Card */}
      <div className="my-auto py-8 text-center z-10 flex flex-col items-center">
        {/* Animated Gold Checkmark */}
        <motion.div
          initial={{ scale: 0.4, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', damping: 15, stiffness: 180 }}
          className={`relative w-28 h-28 rounded-full flex items-center justify-center mb-8 shadow-md border ${
            isDarkMode ? 'bg-[#0E1A2B] border-blue-900/30' : 'bg-white border-gray-100'
          }`}
        >
          {/* Pulsing Outer Ring */}
          <div className="absolute inset-0 rounded-full border-2 border-amber-500/20 animate-[ping_2s_infinite]" />
          
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-inner text-white">
            <Check className="h-10 w-10 stroke-[3.5]" />
          </div>
        </motion.div>

        {/* Welcome Text */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-2 max-w-xs"
        >
          <h2 className={`font-serif font-bold text-2xl leading-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            Welcome to 7 Waves
          </h2>
          <div className={`inline-block font-sans font-bold text-sm px-4 py-1.5 rounded-full mt-2 border ${
            isDarkMode ? 'bg-[#0E1A2B] text-amber-400 border-blue-950' : 'bg-gray-950 text-white border-gray-850'
          }`}>
            Table {tableId} Confirmed
          </div>
          <p className="text-xs text-gray-400 leading-relaxed pt-2">
            Exquisite culinary concepts served directly to your table with zero delays.
          </p>
        </motion.div>
      </div>

      {/* Footer Start Ordering CTA */}
      <div className="pb-12 z-10 text-center">
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
          whileTap={{ scale: 0.98 }}
          onClick={onStartOrdering}
          className="w-full bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-white font-sans font-bold text-sm py-4 px-8 rounded-full shadow-[0_4px_20px_rgba(245,197,66,0.3)] transition-all duration-200 cursor-pointer flex items-center justify-center space-x-2"
        >
          <span>Start Luxury Ordering</span>
        </motion.button>
        <p className="text-[10px] text-gray-400 mt-3 flex items-center justify-center space-x-1">
          <Waves className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
          <span>Fine Dining Digital Concierge v2.6</span>
        </p>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { 
  ChefHat, Settings, QrCode, Plus, Edit2, Trash2, CheckCircle, Clock, 
  ToggleLeft, ToggleRight, X, Image, Upload, AlertCircle, ShoppingBag, 
  ArrowRight, Sparkles, Waves, Trash, DollarSign, RefreshCw 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { MenuItem, Order } from '../types';
import QRGenerator from './QRGenerator';

interface StaffPortalProps {
  onSimulateTableScan: (tableId: string) => void;
  activeTableId: string | null;
  onClose: () => void;
  isDarkMode: boolean;
  customBaseUrl: string;
  onUpdateCustomBaseUrl: (url: string) => void;
  onMenuUpdated: () => void; // Call when items are modified to refresh main menu
  initialTab?: 'kitchen' | 'menu_manager' | 'qr_hub';
}

export default function StaffPortal({
  onSimulateTableScan,
  activeTableId,
  onClose,
  isDarkMode,
  customBaseUrl,
  onUpdateCustomBaseUrl,
  onMenuUpdated,
  initialTab = 'kitchen'
}: StaffPortalProps) {
  const [activeTab, setActiveTab] = useState<'kitchen' | 'menu_manager' | 'qr_hub'>(initialTab);

  // Orders and Menu States
  const [orders, setOrders] = useState<Order[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [menuLoading, setMenuLoading] = useState(true);

  // Edit/Add Menu Item Form Overlay State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  
  // Form Fields
  const [formName, setFormName] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formCategory, setFormCategory] = useState<'starters' | 'mains' | 'seafood' | 'drinks' | 'desserts'>('starters');
  const [formDesc, setFormDesc] = useState('');
  const [formImage, setFormImage] = useState('');
  const [formIngredients, setFormIngredients] = useState('');
  const [formIsVeg, setFormIsVeg] = useState(true);
  const [formIsBestseller, setFormIsBestseller] = useState(false);
  const [formPrepTime, setFormPrepTime] = useState('15 mins');
  const [uploadingImage, setUploadingImage] = useState(false);

  // Real-time sound notification on new order
  const playNotificationSound = () => {
    try {
      const context = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = context.createOscillator();
      const gain = context.createGain();
      osc.connect(gain);
      gain.connect(context.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, context.currentTime); // D5
      osc.frequency.setValueAtTime(880.00, context.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.1, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, context.currentTime + 0.4);
      osc.start();
      osc.stop(context.currentTime + 0.4);
    } catch (e) {
      console.warn('Audio play blocked or not supported:', e);
    }
  };

  // Fetch orders from backend
  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        // Sort orders so pending/received are first
        const sorted = data.sort((a: any, b: any) => b.id.localeCompare(a.id));
        setOrders(sorted);
      }
    } catch (err) {
      console.error('Error fetching orders:', err);
    } finally {
      setOrdersLoading(false);
    }
  };

  // Fetch menu from backend
  const fetchMenu = async () => {
    try {
      const res = await fetch('/api/menu_items');
      if (res.ok) {
        const data = await res.json();
        setMenuItems(data);
      }
    } catch (err) {
      console.error('Error fetching menu:', err);
    } finally {
      setMenuLoading(false);
    }
  };

  // Set up SSE Event Listener for real-time kitchen updates
  useEffect(() => {
    fetchOrders();
    fetchMenu();

    const eventSource = new EventSource('/api/orders/stream');
    
    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'new_order') {
          playNotificationSound();
          // Prepend new order
          setOrders(prev => [payload.data, ...prev]);
        } else if (payload.type === 'status_update') {
          // Update status of matching order
          const updatedOrder = payload.data;
          setOrders(prev => prev.map(o => o.id === updatedOrder.id ? updatedOrder : o));
        }
      } catch (e) {
        console.error('Error parsing SSE payload:', e);
      }
    };

    return () => {
      eventSource.close();
    };
  }, []);

  // Handle Order Status Advance
  const handleAdvanceOrderStatus = async (orderId: string, currentStatus: string) => {
    let nextStatus = '';
    if (currentStatus === 'pending' || currentStatus === 'received') nextStatus = 'preparing';
    else if (currentStatus === 'preparing') nextStatus = 'almost_ready';
    else if (currentStatus === 'almost_ready') nextStatus = 'served';
    else return;

    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res.ok) {
        // Updated state will be synced by SSE broadcast, but let's update locally for instant response
        const updated = await res.json();
        setOrders(prev => prev.map(o => o.id === orderId ? updated : o));
      }
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  // Handle Cancel Order
  const handleCancelOrder = async (orderId: string) => {
    if (!confirm('Are you sure you want to cancel this order?')) return;
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'cancelled' })
      });
      if (res.ok) {
        const updated = await res.json();
        setOrders(prev => prev.map(o => o.id === orderId ? updated : o));
      }
    } catch (err) {
      console.error('Failed to cancel order:', err);
    }
  };

  // Toggle Menu Item Availability
  const handleToggleAvailability = async (itemId: string) => {
    try {
      const res = await fetch(`/api/menu_items/${itemId}/toggle`, {
        method: 'PATCH'
      });
      if (res.ok) {
        const updated = await res.json();
        setMenuItems(prev => prev.map(item => item.id === itemId ? updated : item));
        onMenuUpdated();
      }
    } catch (err) {
      console.error('Toggle availability failed:', err);
    }
  };

  // Image Upload handler (Base64 helper)
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      try {
        setUploadingImage(true);
        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ imageBase64: base64String })
        });
        if (res.ok) {
          const data = await res.json();
          setFormImage(data.imageUrl);
        } else {
          throw new Error('Server returned upload error');
        }
      } catch (err: any) {
        console.error(err);
        alert('Image upload failed. Please try a smaller image or enter URL directly.');
      } finally {
        setUploadingImage(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Open Form for Adding
  const handleOpenAddForm = () => {
    setEditingItem(null);
    setFormName('');
    setFormPrice('');
    setFormCategory('starters');
    setFormDesc('');
    setFormImage('');
    setFormIngredients('');
    setFormIsVeg(true);
    setFormIsBestseller(false);
    setFormPrepTime('15 mins');
    setIsFormOpen(true);
  };

  // Open Form for Editing
  const handleOpenEditForm = (item: MenuItem) => {
    setEditingItem(item);
    setFormName(item.name);
    setFormPrice(item.price.toString());
    setFormCategory(item.category);
    setFormDesc(item.desc || '');
    setFormImage(item.image);
    setFormIngredients(item.ingredients ? item.ingredients.join(', ') : '');
    setFormIsVeg(!!item.isVeg);
    setFormIsBestseller(!!item.isBestseller);
    setFormPrepTime(item.prepTime || '15 mins');
    setIsFormOpen(true);
  };

  // Handle Form Submit (Add or Edit)
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formPrice || !formCategory) {
      alert('Please fill in Name, Price, and Category');
      return;
    }

    const payload = {
      name: formName,
      price: Number(formPrice),
      category: formCategory,
      desc: formDesc,
      image: formImage || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=600&auto=format&fit=crop',
      ingredients: formIngredients.split(',').map(s => s.trim()).filter(Boolean),
      isVeg: formIsVeg,
      isBestseller: formIsBestseller,
      prepTime: formPrepTime
    };

    try {
      let res;
      if (editingItem) {
        // EDIT
        res = await fetch(`/api/menu_items/${editingItem.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } else {
        // ADD
        res = await fetch('/api/menu_items', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }

      if (res.ok) {
        setIsFormOpen(false);
        fetchMenu();
        onMenuUpdated();
      } else {
        const errorData = await res.json();
        alert('Action failed: ' + (errorData.error || 'Unknown error'));
      }
    } catch (err) {
      console.error('Error saving menu item:', err);
    }
  };

  return (
    <div className={`min-h-screen pb-20 transition-colors duration-300 ${
      isDarkMode ? 'bg-[#050508] text-white' : 'bg-[#F7F9FC] text-gray-950'
    }`}>
      {/* Header Bar */}
      <header className={`sticky top-0 z-30 border-b backdrop-blur-md transition-colors duration-300 ${
        isDarkMode ? 'bg-[#0E1A2B]/90 border-blue-900/30' : 'bg-white/90 border-gray-150'
      }`}>
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ChefHat className="h-5 w-5 text-amber-500" />
            <div>
              <h1 className="font-serif font-black text-lg">Waves Staff Portal</h1>
              <p className="text-[10px] text-amber-500 font-sans font-bold uppercase tracking-widest leading-none mt-0.5">
                Kitchen & Menu Operations
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-sans font-bold text-xs rounded-full shadow-sm transition-all cursor-pointer"
          >
            Exit Portal
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 mt-6">
        {/* Navigation Tabs */}
        <div className="flex space-x-1.5 p-1 bg-black/10 dark:bg-white/5 rounded-2xl max-w-md mb-6 border border-gray-200/20">
          <button
            onClick={() => setActiveTab('kitchen')}
            className={`flex-1 flex items-center justify-center space-x-1.5 py-2.5 rounded-xl text-xs font-sans font-extrabold transition-all cursor-pointer ${
              activeTab === 'kitchen'
                ? 'bg-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-amber-500'
            }`}
          >
            <ChefHat className="h-3.5 w-3.5" />
            <span>Kitchen Dashboard</span>
            {orders.filter(o => o.status === 'pending' || o.status === 'received' || o.status === 'preparing').length > 0 && (
              <span className="bg-red-500 text-white text-[9px] px-1.5 py-0.5 rounded-full font-black animate-pulse">
                {orders.filter(o => o.status === 'pending' || o.status === 'received' || o.status === 'preparing').length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('menu_manager')}
            className={`flex-1 flex items-center justify-center space-x-1.5 py-2.5 rounded-xl text-xs font-sans font-extrabold transition-all cursor-pointer ${
              activeTab === 'menu_manager'
                ? 'bg-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-amber-500'
            }`}
          >
            <Settings className="h-3.5 w-3.5" />
            <span>Menu Manager</span>
          </button>

          <button
            onClick={() => setActiveTab('qr_hub')}
            className={`flex-1 flex items-center justify-center space-x-1.5 py-2.5 rounded-xl text-xs font-sans font-extrabold transition-all cursor-pointer ${
              activeTab === 'qr_hub'
                ? 'bg-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-amber-500'
            }`}
          >
            <QrCode className="h-3.5 w-3.5" />
            <span>Table QRs</span>
          </button>
        </div>

        {/* TAB 1: KITCHEN DASHBOARD */}
        {activeTab === 'kitchen' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-gray-150 dark:border-blue-950 pb-3">
              <div>
                <h2 className="font-serif font-black text-xl">Live Cooking Monitor</h2>
                <p className="text-xs text-gray-400 mt-0.5">
                  Real-time table orders update. Tap status button to advance dish preparation stages.
                </p>
              </div>
              <button 
                onClick={fetchOrders}
                className="p-2 bg-black/5 hover:bg-black/10 dark:bg-white/5 dark:hover:bg-white/10 rounded-xl transition-all cursor-pointer"
                title="Refresh Orders"
              >
                <RefreshCw className="h-4 w-4 text-amber-500 animate-spin" style={{ animationDuration: '6s' }} />
              </button>
            </div>

            {ordersLoading ? (
              <div className="text-center py-12">
                <RefreshCw className="h-8 w-8 text-amber-500 animate-spin mx-auto mb-2" />
                <p className="text-xs text-gray-400">Loading orders database...</p>
              </div>
            ) : orders.length === 0 ? (
              <div className="text-center py-16 rounded-3xl border border-dashed border-gray-200/40 p-6">
                <ShoppingBag className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                <h3 className="font-serif font-bold text-base">No active orders yet</h3>
                <p className="text-xs text-gray-400 mt-1 max-w-xs mx-auto">
                  Diner orders placed via tabletop QR codes will flash here instantly with real-time status syncing.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {orders.map((order) => {
                  const isDone = order.status === 'served' || order.status === 'cancelled';
                  const isPreparing = order.status === 'preparing';
                  const isAlmostReady = order.status === 'almost_ready';
                  const isNew = order.status === 'received' || order.status === 'pending';

                  let borderStyle = 'border-gray-200/60 dark:border-blue-950';
                  let badgeStyle = 'bg-gray-100 text-gray-800 dark:bg-blue-950/40 dark:text-gray-400';
                  
                  if (isNew) {
                    borderStyle = 'border-amber-500/50 shadow-md ring-2 ring-amber-500/10';
                    badgeStyle = 'bg-amber-500/10 text-amber-500 border border-amber-500/30 font-black animate-pulse';
                  } else if (isPreparing) {
                    borderStyle = 'border-sky-500/40';
                    badgeStyle = 'bg-sky-500/15 text-sky-400 border border-sky-500/30';
                  } else if (isAlmostReady) {
                    borderStyle = 'border-emerald-500/40';
                    badgeStyle = 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30';
                  } else if (order.status === 'served') {
                    borderStyle = 'border-gray-100/30 opacity-70';
                    badgeStyle = 'bg-emerald-500/10 text-emerald-500/80';
                  } else if (order.status === 'cancelled') {
                    borderStyle = 'border-red-500/20 opacity-50';
                    badgeStyle = 'bg-red-500/10 text-red-500';
                  }

                  return (
                    <motion.div
                      layout
                      key={order.id}
                      className={`rounded-2xl p-4 border ${borderStyle} transition-all duration-300 ${
                        isDarkMode ? 'bg-[#0E1A2B]' : 'bg-white shadow-sm'
                      }`}
                    >
                      {/* Order Header */}
                      <div className="flex items-center justify-between border-b border-gray-100/10 pb-3 mb-3">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-serif font-black text-amber-500 text-base">
                              Order #{order.id}
                            </span>
                            <span className="text-[10px] text-gray-400 font-mono">
                              {order.timestamp}
                            </span>
                          </div>
                          <span className="text-xs font-sans font-bold dark:text-gray-300 block mt-0.5">
                            Table {order.tableId} • Beachside Dining
                          </span>
                        </div>
                        <span className={`text-[9px] uppercase font-sans font-bold px-2.5 py-1 rounded-full ${badgeStyle}`}>
                          {order.status === 'received' ? 'Pending' : order.status}
                        </span>
                      </div>

                      {/* Items Ordered */}
                      <div className="space-y-2.5 mb-4">
                        {(order as any).items?.map((item: any) => (
                          <div key={item.id} className="flex items-start justify-between text-xs gap-3">
                            <div className="flex-1 min-w-0">
                              <p className="font-sans font-bold dark:text-white truncate">
                                {item.menuItem?.name || 'Loading Item...'}
                              </p>
                              {/* Item options */}
                              <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                                <span className="text-[10px] text-amber-500 font-mono font-bold">
                                  Qty: {item.quantity}
                                </span>
                                {item.spiceLevel && (
                                  <span className="text-[9px] bg-red-500/5 text-red-400 border border-red-500/10 px-1 rounded">
                                    {item.spiceLevel}
                                  </span>
                                )}
                              </div>
                              {item.customNotes && (
                                <p className="text-[10px] text-amber-500 italic mt-1 bg-amber-500/5 px-2 py-0.5 rounded border border-amber-500/10 font-sans">
                                  “{item.customNotes}”
                                </p>
                              )}
                            </div>
                            <span className="font-bold font-mono text-gray-400 shrink-0">
                              ₹{(item.menuItem?.price || item.priceAtOrder) * item.quantity}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Order Actions */}
                      <div className="border-t border-gray-100/5 pt-3.5 flex items-center justify-between gap-2 flex-wrap">
                        <div className="text-left">
                          <span className="text-[9px] text-gray-400 uppercase tracking-widest block font-bold leading-none">
                            Grand Total
                          </span>
                          <span className="font-serif font-black text-sm text-amber-500">
                            ₹{order.total}
                          </span>
                        </div>

                        {!isDone ? (
                          <div className="flex items-center space-x-2">
                            {/* Cancel Button */}
                            <button
                              onClick={() => handleCancelOrder(order.id)}
                              className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl transition-all cursor-pointer"
                              title="Cancel Order"
                            >
                              <Trash className="h-4 w-4" />
                            </button>

                            {/* Advance Status button */}
                            <button
                              onClick={() => handleAdvanceOrderStatus(order.id, order.status)}
                              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-sans font-bold text-xs rounded-xl shadow-xs transition-all flex items-center space-x-1 cursor-pointer"
                            >
                              <span>
                                {order.status === 'received' || order.status === 'pending' ? 'Accept / Cook' : 
                                 order.status === 'preparing' ? 'Mark Ready' : 
                                 order.status === 'almost_ready' ? 'Mark Served' : 'Advance'}
                              </span>
                              <ArrowRight className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-gray-500 flex items-center gap-1 font-sans font-bold uppercase tracking-wider">
                            <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                            <span>Completed Order</span>
                          </span>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: MENU MANAGER */}
        {activeTab === 'menu_manager' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-gray-150 dark:border-blue-950 pb-3">
              <div>
                <h2 className="font-serif font-black text-xl">Dynamic Menu Catalog</h2>
                <p className="text-xs text-gray-400 mt-0.5">
                  Update pricing, category labels, image links, and instantly trigger Diner availability toggles.
                </p>
              </div>
              <button
                onClick={handleOpenAddForm}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-sans font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center space-x-1.5 cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                <span>Add New Dish</span>
              </button>
            </div>

            {menuLoading ? (
              <div className="text-center py-12">
                <RefreshCw className="h-8 w-8 text-amber-500 animate-spin mx-auto mb-2" />
                <p className="text-xs text-gray-400">Syncing with database catalog...</p>
              </div>
            ) : (
              <div className="space-y-3.5 max-h-[calc(100vh-16rem)] overflow-y-auto pr-1">
                {menuItems.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-2xl border transition-all duration-200 flex flex-col sm:flex-row items-center justify-between gap-4 ${
                      item.available === false
                        ? 'opacity-60 bg-gray-500/5 border-dashed border-gray-200/20'
                        : isDarkMode
                          ? 'bg-[#0E1A2B] border-blue-950 hover:border-amber-500/20'
                          : 'bg-white border-gray-150 shadow-xs'
                    }`}
                  >
                    {/* Item Info Card */}
                    <div className="flex items-center space-x-4 w-full sm:w-auto">
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-14 h-14 object-cover rounded-xl shrink-0 border border-gray-100/10 shadow-xs"
                      />
                      <div className="text-left min-w-0">
                        <div className="flex items-center space-x-2">
                          <span className="text-[8px] uppercase font-sans font-black tracking-widest text-amber-500">
                            {item.category}
                          </span>
                          {item.isVeg && (
                            <span className="text-[8px] bg-emerald-500/15 text-emerald-500 px-1 rounded-sm font-bold uppercase">
                              VEG 🌱
                            </span>
                          )}
                          {item.isBestseller && (
                            <span className="text-[8px] bg-amber-500/20 text-amber-400 px-1 rounded-sm font-bold uppercase">
                              ⭐ Star
                            </span>
                          )}
                        </div>
                        <h4 className="font-sans font-bold text-sm truncate dark:text-white mt-0.5">
                          {item.name}
                        </h4>
                        <p className="text-[10px] text-gray-400 line-clamp-1 mt-0.5">
                          {item.desc}
                        </p>
                      </div>
                    </div>

                    {/* Pricing & Control Toggles */}
                    <div className="flex items-center justify-between sm:justify-end gap-5 w-full sm:w-auto border-t sm:border-t-0 pt-3 sm:pt-0 border-dashed border-gray-100/10">
                      <div className="text-left sm:text-right">
                        <span className="text-[9px] text-gray-400 uppercase tracking-widest block font-bold leading-none">
                          Active Price
                        </span>
                        <span className="font-serif font-black text-sm text-[#F5C542]">
                          ₹{item.price}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2.5">
                        {/* Toggle active / disabled switch */}
                        <button
                          onClick={() => handleToggleAvailability(item.id)}
                          className="flex items-center space-x-1 py-1.5 px-3 rounded-lg border dark:border-blue-900/30 text-[10px] font-sans font-black uppercase transition-all cursor-pointer bg-black/5 dark:bg-[#050508]"
                        >
                          {item.available !== false ? (
                            <>
                              <ToggleRight className="h-4.5 w-4.5 text-emerald-500" />
                              <span className="text-emerald-500">Listed</span>
                            </>
                          ) : (
                            <>
                              <ToggleLeft className="h-4.5 w-4.5 text-gray-400" />
                              <span className="text-gray-400">Disabled</span>
                            </>
                          )}
                        </button>

                        {/* Edit Button */}
                        <button
                          onClick={() => handleOpenEditForm(item)}
                          className="p-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 rounded-xl transition-all cursor-pointer"
                          title="Edit Details"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: TABLE QR CODES */}
        {activeTab === 'qr_hub' && (
          <div className="space-y-6">
            <div className="border-b border-gray-150 dark:border-blue-950 pb-3">
              <h2 className="font-serif font-black text-xl">Table Placard Hub</h2>
              <p className="text-xs text-gray-400 mt-0.5">
                Physical printed codes or simulation triggers for physical dining tables.
              </p>
            </div>

            <QRGenerator
              onSimulateTableScan={onSimulateTableScan}
              activeTableId={activeTableId}
              onClose={onClose}
              isDarkMode={isDarkMode}
              customBaseUrl={customBaseUrl}
              onUpdateCustomBaseUrl={onUpdateCustomBaseUrl}
            />
          </div>
        )}
      </main>

      {/* DYNAMIC FORM MODAL (ADD / EDIT DISH) */}
      <AnimatePresence>
        {isFormOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
            <div className="absolute inset-0 cursor-pointer" onClick={() => setIsFormOpen(false)} />
            
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`relative w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl z-10 border transition-all duration-300 p-6 max-h-[90vh] overflow-y-auto ${
                isDarkMode 
                  ? 'bg-[#0E1A2B] text-white border-blue-900/40' 
                  : 'bg-white text-gray-900 border-gray-150'
              }`}
            >
              <button
                onClick={() => setIsFormOpen(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-white/10 text-gray-400 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="flex items-center space-x-2 border-b border-gray-100/10 pb-3.5 mb-5">
                <ChefHat className="h-5 w-5 text-amber-500" />
                <h3 className="font-serif font-black text-lg">
                  {editingItem ? `Edit Delicacy: ${editingItem.name}` : 'Create New Menu Item'}
                </h3>
              </div>

              <form onSubmit={handleFormSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-wider text-amber-500 mb-1.5">
                      Dish Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="e.g. Lobster Tail Flambé"
                      className={`w-full text-xs p-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                        isDarkMode 
                          ? 'bg-[#0B0B0F] border-blue-950 text-white placeholder-gray-600' 
                          : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                      }`}
                    />
                  </div>

                  {/* Price field */}
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-wider text-amber-500 mb-1.5">
                      Price (INR) *
                    </label>
                    <div className="relative flex items-center">
                      <span className="absolute left-3 text-gray-500 text-xs font-bold">₹</span>
                      <input
                        type="number"
                        required
                        value={formPrice}
                        onChange={(e) => setFormPrice(e.target.value)}
                        placeholder="e.g. 799"
                        className={`w-full text-xs pl-7 pr-3 py-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                          isDarkMode 
                            ? 'bg-[#0B0B0F] border-blue-950 text-white placeholder-gray-600' 
                            : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                        }`}
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Category select */}
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-wider text-amber-500 mb-1.5">
                      Category Category *
                    </label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as any)}
                      className={`w-full text-xs p-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                        isDarkMode 
                          ? 'bg-[#0B0B0F] border-blue-950 text-white' 
                          : 'bg-gray-50 border-gray-200 text-gray-800'
                      }`}
                    >
                      <option value="starters">Starters / Appetizers</option>
                      <option value="mains">Main Courses</option>
                      <option value="seafood">Exquisite Seafood</option>
                      <option value="drinks">Mocktails & Drinks</option>
                      <option value="desserts">Artisanal Desserts</option>
                    </select>
                  </div>

                  {/* Prep Time */}
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-wider text-amber-500 mb-1.5">
                      Prep Time
                    </label>
                    <input
                      type="text"
                      value={formPrepTime}
                      onChange={(e) => setFormPrepTime(e.target.value)}
                      placeholder="e.g. 15 mins"
                      className={`w-full text-xs p-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                        isDarkMode 
                          ? 'bg-[#0B0B0F] border-blue-950 text-white placeholder-gray-600' 
                          : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                      }`}
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-amber-500 mb-1.5">
                    Culinary Description
                  </label>
                  <textarea
                    value={formDesc}
                    onChange={(e) => setFormDesc(e.target.value)}
                    placeholder="Describe the flavors, texture, and notes..."
                    rows={2}
                    className={`w-full text-xs p-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                      isDarkMode 
                        ? 'bg-[#0B0B0F] border-blue-950 text-white placeholder-gray-600' 
                        : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                    }`}
                  />
                </div>

                {/* Image and Upload Field */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-amber-500 mb-1.5">
                    Dish Image (Direct Upload or Link URL)
                  </label>
                  
                  <div className="flex flex-col gap-2.5">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={formImage}
                        onChange={(e) => setFormImage(e.target.value)}
                        placeholder="Paste image URL (Unsplash, etc.)"
                        className={`flex-1 text-xs p-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                          isDarkMode 
                            ? 'bg-[#0B0B0F] border-blue-950 text-white placeholder-gray-600' 
                            : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                        }`}
                      />
                      
                      {/* Direct Upload File Input */}
                      <label className="p-3 bg-amber-500/10 hover:bg-amber-500/15 border border-dashed border-amber-500/40 text-amber-500 rounded-xl flex items-center justify-center cursor-pointer transition-all gap-1.5 text-xs font-bold font-sans shrink-0">
                        {uploadingImage ? (
                          <RefreshCw className="h-4 w-4 animate-spin text-amber-500" />
                        ) : (
                          <Upload className="h-4 w-4 text-amber-500" />
                        )}
                        <span>{uploadingImage ? 'Uploading...' : 'Upload Image'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          disabled={uploadingImage}
                          className="hidden"
                        />
                      </label>
                    </div>

                    {formImage && (
                      <div className="flex items-center space-x-3.5 bg-black/10 p-2.5 rounded-xl border dark:border-blue-950/40">
                        <img
                          src={formImage}
                          alt="Preview"
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 object-cover rounded-lg border border-white/5 shrink-0"
                        />
                        <div className="text-left min-w-0">
                          <span className="text-[8px] uppercase tracking-wider text-emerald-400 font-bold block">
                            Image Link Configured
                          </span>
                          <span className="text-[10px] text-gray-400 font-mono block truncate">
                            {formImage}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Ingredients (comma separated) */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-amber-500 mb-1.5">
                    Ingredients (Comma separated tags)
                  </label>
                  <input
                    type="text"
                    value={formIngredients}
                    onChange={(e) => setFormIngredients(e.target.value)}
                    placeholder="e.g. Premium Saffron, Mascarpone, Coffee, Truffle Oil"
                    className={`w-full text-xs p-3 rounded-xl border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                      isDarkMode 
                        ? 'bg-[#0B0B0F] border-blue-950 text-white placeholder-gray-600' 
                        : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                    }`}
                  />
                </div>

                {/* Switch sliders */}
                <div className="grid grid-cols-2 gap-4 border-t border-gray-100/10 pt-3.5">
                  <label className="flex items-center justify-between cursor-pointer p-2 rounded-xl bg-black/5 dark:bg-[#0B0B0F]/40 border dark:border-blue-950/20">
                    <span className="text-[10px] font-sans font-extrabold uppercase tracking-wider text-gray-400">
                      Vegetarian 🌱
                    </span>
                    <button
                      type="button"
                      onClick={() => setFormIsVeg(!formIsVeg)}
                      className="cursor-pointer"
                    >
                      {formIsVeg ? (
                        <ToggleRight className="h-6 w-6 text-emerald-500" />
                      ) : (
                        <ToggleLeft className="h-6 w-6 text-gray-400" />
                      )}
                    </button>
                  </label>

                  <label className="flex items-center justify-between cursor-pointer p-2 rounded-xl bg-black/5 dark:bg-[#0B0B0F]/40 border dark:border-blue-950/20">
                    <span className="text-[10px] font-sans font-extrabold uppercase tracking-wider text-gray-400">
                      Bestseller ⭐
                    </span>
                    <button
                      type="button"
                      onClick={() => setFormIsBestseller(!formIsBestseller)}
                      className="cursor-pointer"
                    >
                      {formIsBestseller ? (
                        <ToggleRight className="h-6 w-6 text-amber-500" />
                      ) : (
                        <ToggleLeft className="h-6 w-6 text-gray-400" />
                      )}
                    </button>
                  </label>
                </div>

                {/* Actions */}
                <div className="flex justify-end space-x-2.5 pt-4 border-t border-gray-100/5">
                  <button
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="px-4 py-2 text-xs font-sans font-bold uppercase tracking-wider text-gray-400 hover:text-gray-300 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-sans font-extrabold text-xs shadow-md transition-all cursor-pointer"
                  >
                    {editingItem ? 'Save Updates' : 'Add Dish'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

import React from 'react';
import { Plus, Minus, Flame, Star, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { MenuItem } from '../types';

interface FoodCardProps {
  key?: string;
  item: MenuItem;
  quantityInCart: number;
  onIncrement: () => void;
  onDecrement: () => void;
  onClick: () => void;
  isDarkMode?: boolean;
}

export default function FoodCard({
  item,
  quantityInCart,
  onIncrement,
  onDecrement,
  onClick,
  isDarkMode = false
}: FoodCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-20px' }}
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      className={`rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col h-full group border ${
        isDarkMode
          ? 'bg-[#0E1A2B]/40 backdrop-blur-md border-blue-900/30 shadow-blue-950/20'
          : 'bg-white border-gray-100/70'
      }`}
    >
      {/* Food Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden bg-gray-50/5 cursor-pointer" onClick={onClick}>
        <img
          src={item.image}
          alt={item.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
        />
        {/* Shadow overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
        
        {/* Floating Tags */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {/* Spicy tag */}
          {item.spicinessLevel && (
            <div className="bg-red-500/90 text-white text-[9px] font-sans font-bold px-2 py-0.5 rounded-md flex items-center space-x-0.5 backdrop-blur-xs shadow-sm">
              <Flame className="h-3 w-3 fill-white text-red-500" />
              <span>Spicy</span>
            </div>
          )}

          {/* Bestseller badge */}
          {item.isBestseller && (
            <div className="bg-amber-500 text-white text-[9px] font-sans font-extrabold px-2 py-0.5 rounded-md flex items-center space-x-0.5 shadow-sm">
              <Sparkles className="h-3 w-3 animate-pulse" />
              <span>BESTSELLER</span>
            </div>
          )}
        </div>

        {/* Veg / Non-Veg badge on the top right */}
        <div className="absolute top-3 right-3 z-10">
          {item.isVeg ? (
            <div className="w-5 h-5 bg-white rounded-md flex items-center justify-center border border-emerald-500 p-0.5 shadow-sm">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            </div>
          ) : (
            <div className="w-5 h-5 bg-white rounded-md flex items-center justify-center border border-red-500 p-0.5 shadow-sm">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
            </div>
          )}
        </div>

        {/* Floating Rating Badge */}
        {item.rating && (
          <div className="absolute bottom-3 left-3 bg-black/50 backdrop-blur-md text-white text-[10px] font-sans font-bold px-2 py-0.5 rounded-md flex items-center space-x-0.5 border border-white/10">
            <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
            <span>{item.rating}</span>
          </div>
        )}

        {/* Price Tag */}
        <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-md px-2.5 py-0.5 rounded-lg shadow-sm border border-white/50">
          <span className="font-serif font-black text-amber-600 text-sm">
            ₹{item.price}
          </span>
        </div>
      </div>

      {/* Content Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div className="cursor-pointer" onClick={onClick}>
          <h3 className={`font-serif font-bold text-base leading-tight mb-1 transition-colors duration-200 line-clamp-1 ${
            isDarkMode 
              ? 'text-white group-hover:text-amber-400' 
              : 'text-gray-950 group-hover:text-amber-600'
          }`}>
            {item.name}
          </h3>
          <p className={`text-xs line-clamp-2 leading-relaxed mb-4 ${
            isDarkMode ? 'text-gray-400' : 'text-gray-500'
          }`}>
            {item.desc}
          </p>
        </div>

        {/* Action Button & Prep details */}
        <div className={`flex items-center justify-between mt-auto pt-2.5 border-t ${
          isDarkMode ? 'border-blue-950' : 'border-gray-50'
        }`}>
          <span className={`text-[9px] font-sans tracking-wider uppercase font-bold ${
            isDarkMode ? 'text-amber-400/80' : 'text-gray-400'
          }`}>
            {item.prepTime || '15 mins'} prep
          </span>

          {quantityInCart === 0 ? (
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.stopPropagation();
                onIncrement();
              }}
              className="bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-full p-2.5 shadow-md transition-all duration-200 flex items-center justify-center cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
            </motion.button>
          ) : (
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className={`flex items-center rounded-full px-1.5 py-0.5 space-x-3 shadow-xs border ${
                isDarkMode 
                  ? 'bg-blue-950/40 border-blue-900/40' 
                  : 'bg-gray-50 border-gray-150'
              }`}
            >
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDecrement();
                }}
                className={`w-6.5 h-6.5 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-xs border ${
                  isDarkMode
                    ? 'bg-[#0B0B0F] hover:bg-[#15253F] border-blue-900/20 text-gray-300'
                    : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-700'
                }`}
              >
                <Minus className="h-2.5 w-2.5" />
              </button>
              <span className={`font-sans font-black text-xs w-3.5 text-center ${
                isDarkMode ? 'text-white' : 'text-gray-950'
              }`}>
                {quantityInCart}
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onIncrement();
                }}
                className="w-6.5 h-6.5 bg-amber-500 text-white rounded-full flex items-center justify-center hover:bg-amber-600 transition-all cursor-pointer shadow-xs"
              >
                <Plus className="h-2.5 w-2.5" />
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
